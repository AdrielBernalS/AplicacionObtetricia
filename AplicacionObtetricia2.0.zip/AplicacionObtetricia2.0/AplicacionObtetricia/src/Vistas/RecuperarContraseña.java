
package Vistas;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.Timer;
import javax.swing.UIManager;
public class RecuperarContraseña extends javax.swing.JDialog {

    private Login loginParent; // Referencia al login
    int xMouse, yMouse;

    public RecuperarContraseña(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setSize(558, 624);
        this.loginParent = (Login) parent; 
        setLocationRelativeTo(parent);
        this.getRootPane().requestFocus();  // Quita el foco de los campos de texto
        ocultarTodosLosErrores(); // Oculta todos los errores al inicio

        CONTRASEÑANUEVA.setVisible(false);
        jPasswordContNueva.setVisible(false);
        jSeparator4.setVisible(false);
        CONFIRMARCONTRASEÑA.setVisible(false);
        jPasswordContNuevConf.setVisible(false);
        jSeparator1.setVisible(false);
        jButtonGuardarysalir.setVisible(false);
        VERCONTNUEVA.setVisible(false);
        OCULTARCONTNUEVA.setVisible(false);
        CONFIRMARVERCONTNUEVA.setVisible(false);
        CONFIRMAROCULTARCONTNUEVA.setVisible(false);
        labelContraseñaVacioNueva.setVisible(false);
        labelContraseñaVacioConfirmacion.setVisible(false);
        labelContraseñaNoCoincide.setVisible(false);
        
        
        jTextNombredeUsuarioRecuperar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                if (jTextNombredeUsuarioRecuperar.getText().equals("Ingrese su nombre de usuario")) {
                    jTextNombredeUsuarioRecuperar.setText("");
                    jTextNombredeUsuarioRecuperar.setForeground(Color.black);
                }
            }

            public void focusLost(java.awt.event.FocusEvent evt) {
                if (jTextNombredeUsuarioRecuperar.getText().isEmpty()) {
                    jTextNombredeUsuarioRecuperar.setText("Ingrese su nombre de usuario");
                    jTextNombredeUsuarioRecuperar.setForeground(Color.gray);
                }
            }
        });
        jTextDni.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                if (jTextDni.getText().equals("Ingrese su dni")) {
                    jTextDni.setText("");
                    jTextDni.setForeground(Color.black);
                }
            }

            public void focusLost(java.awt.event.FocusEvent evt) {
                if (jTextDni.getText().isEmpty()) {
                    jTextDni.setText("Ingrese su dni");
                    jTextDni.setForeground(Color.gray);
                }
            }
        });
        jPasswordContNueva.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent evt) {
                if (String.valueOf(jPasswordContNueva.getPassword()).equals("********")) {
                    jPasswordContNueva.setText("");
                    jPasswordContNueva.setForeground(Color.BLACK);
                    jPasswordContNueva.setEchoChar('•'); // Activa el ocultamiento
                }
            }

            @Override
            public void focusLost(java.awt.event.FocusEvent evt) {
                if (String.valueOf(jPasswordContNueva.getPassword()).isEmpty()) {
                    jPasswordContNueva.setText("********");
                    jPasswordContNueva.setForeground(Color.GRAY);
                    jPasswordContNueva.setEchoChar((char) 0); // Muestra texto plano
                }
            }
        });
        jPasswordContNuevConf.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent evt) {
                if (String.valueOf(jPasswordContNuevConf.getPassword()).equals("********")) {
                    jPasswordContNuevConf.setText("");
                    jPasswordContNuevConf.setForeground(Color.BLACK);
                    jPasswordContNuevConf.setEchoChar('•');
                }
            }

            @Override
            public void focusLost(java.awt.event.FocusEvent evt) {
                if (String.valueOf(jPasswordContNuevConf.getPassword()).isEmpty()) {
                    jPasswordContNuevConf.setText("********");
                    jPasswordContNuevConf.setForeground(Color.GRAY);
                    jPasswordContNuevConf.setEchoChar((char) 0);
                }
            }
        });

        jTextNombredeUsuarioRecuperar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                char c = evt.getKeyChar();
                if (!Character.isLetter(c) && !Character.isWhitespace(c)) {
                    evt.consume(); // Bloquea el caracter
                }
            }
        });

        jTextDni.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                char c = evt.getKeyChar();
                if (!Character.isDigit(c)) {
                    evt.consume(); // Bloquea el caracter
                }
                // Limita a 8 caracteres
                if (jTextDni.getText().length() >= 8) {
                    evt.consume(); // Bloquea si ya hay 8 caracteres
                }
            }
        });

    }

    private void ocultarTodosLosErrores() {
        lblErrorUsuarioVacio.setVisible(false);
        lblErrorUsuarioIncorrecto.setVisible(false);
        lblErrorDniVacio.setVisible(false);
        lblErrorDniIncorrecto.setVisible(false);
    }

    private void mostrarErrorUsuarioVacio() {
        lblErrorUsuarioVacio.setVisible(true);
        lblErrorUsuarioIncorrecto.setVisible(false);
    }

    private void mostrarErrorUsuarioIncorrecto() {
        lblErrorUsuarioVacio.setVisible(false);
        lblErrorUsuarioIncorrecto.setVisible(true);
    }

    private void mostrarErrorDniVacio() {
        lblErrorDniVacio.setVisible(true);
        lblErrorDniIncorrecto.setVisible(false);
    }

    private void mostrarErrorDniIncorrecto() {
        lblErrorDniVacio.setVisible(false);
        lblErrorDniIncorrecto.setVisible(true);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        NOMBRE = new javax.swing.JLabel();
        jTextNombredeUsuarioRecuperar = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        DNI = new javax.swing.JLabel();
        jTextDni = new javax.swing.JTextField();
        jSeparator2 = new javax.swing.JSeparator();
        jButtonGuardarysalir = new javax.swing.JButton();
        CONTRASEÑANUEVA = new javax.swing.JLabel();
        jPasswordContNueva = new javax.swing.JPasswordField();
        VERCONTNUEVA = new javax.swing.JLabel();
        OCULTARCONTNUEVA = new javax.swing.JLabel();
        CONFIRMARCONTRASEÑA = new javax.swing.JLabel();
        jPasswordContNuevConf = new javax.swing.JPasswordField();
        CONFIRMARVERCONTNUEVA = new javax.swing.JLabel();
        CONFIRMAROCULTARCONTNUEVA = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        jButtonEnviar = new javax.swing.JButton();
        jPanelMENU = new javax.swing.JPanel();
        jPanelSalir = new javax.swing.JPanel();
        jLabelX = new javax.swing.JLabel();
        jSeparator5 = new javax.swing.JSeparator();
        INICIARSESION = new javax.swing.JLabel();
        lblErrorDniIncorrecto = new javax.swing.JLabel();
        jSeparator6 = new javax.swing.JSeparator();
        lblErrorUsuarioIncorrecto = new javax.swing.JLabel();
        lblErrorUsuarioVacio = new javax.swing.JLabel();
        lblErrorDniVacio = new javax.swing.JLabel();
        labelContraseñaVacioNueva = new javax.swing.JLabel();
        labelContraseñaVacioConfirmacion = new javax.swing.JLabel();
        labelContraseñaNoCoincide = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        Fondo.setBackground(new java.awt.Color(255, 255, 255));
        Fondo.setForeground(new java.awt.Color(255, 255, 255));
        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        NOMBRE.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        NOMBRE.setForeground(new java.awt.Color(51, 51, 51));
        NOMBRE.setText("Nombre");
        Fondo.add(NOMBRE, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 140, -1, -1));

        jTextNombredeUsuarioRecuperar.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        jTextNombredeUsuarioRecuperar.setForeground(new java.awt.Color(204, 204, 204));
        jTextNombredeUsuarioRecuperar.setText("Ingrese su nombre de usuario");
        jTextNombredeUsuarioRecuperar.setBorder(null);
        jTextNombredeUsuarioRecuperar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jTextNombredeUsuarioRecuperarMousePressed(evt);
            }
        });
        jTextNombredeUsuarioRecuperar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextNombredeUsuarioRecuperarActionPerformed(evt);
            }
        });
        Fondo.add(jTextNombredeUsuarioRecuperar, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 170, 300, -1));

        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));
        Fondo.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 510, 370, 20));

        DNI.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        DNI.setForeground(new java.awt.Color(51, 51, 51));
        DNI.setText("DNI");
        Fondo.add(DNI, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 220, -1, -1));

        jTextDni.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        jTextDni.setForeground(new java.awt.Color(204, 204, 204));
        jTextDni.setText("Ingrese su dni");
        jTextDni.setBorder(null);
        jTextDni.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jTextDniMousePressed(evt);
            }
        });
        jTextDni.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextDniActionPerformed(evt);
            }
        });
        Fondo.add(jTextDni, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 250, 300, -1));

        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));
        Fondo.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 270, 370, 20));

        jButtonGuardarysalir.setBackground(new java.awt.Color(204, 204, 204));
        jButtonGuardarysalir.setFont(new java.awt.Font("Roboto Condensed", 0, 18)); // NOI18N
        jButtonGuardarysalir.setText("Guardar");
        jButtonGuardarysalir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonGuardarysalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGuardarysalirActionPerformed(evt);
            }
        });
        Fondo.add(jButtonGuardarysalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 560, 220, 40));

        CONTRASEÑANUEVA.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        CONTRASEÑANUEVA.setForeground(new java.awt.Color(51, 51, 51));
        CONTRASEÑANUEVA.setText("CONTRASEÑA NUEVA");
        Fondo.add(CONTRASEÑANUEVA, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 370, -1, -1));

        jPasswordContNueva.setForeground(new java.awt.Color(204, 204, 204));
        jPasswordContNueva.setText("********");
        jPasswordContNueva.setBorder(null);
        jPasswordContNueva.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPasswordContNuevaMousePressed(evt);
            }
        });
        jPasswordContNueva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordContNuevaActionPerformed(evt);
            }
        });
        Fondo.add(jPasswordContNueva, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 400, 340, -1));

        VERCONTNUEVA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/ver_32px.png"))); // NOI18N
        VERCONTNUEVA.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        VERCONTNUEVA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                VERCONTNUEVAMouseClicked(evt);
            }
        });
        Fondo.add(VERCONTNUEVA, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 390, -1, -1));

        OCULTARCONTNUEVA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/ocultar_32px.png"))); // NOI18N
        OCULTARCONTNUEVA.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        OCULTARCONTNUEVA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OCULTARCONTNUEVAMouseClicked(evt);
            }
        });
        Fondo.add(OCULTARCONTNUEVA, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 390, -1, -1));

        CONFIRMARCONTRASEÑA.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        CONFIRMARCONTRASEÑA.setForeground(new java.awt.Color(51, 51, 51));
        CONFIRMARCONTRASEÑA.setText("CONFIRMAR CONTRASEÑA NUEVA");
        Fondo.add(CONFIRMARCONTRASEÑA, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 460, -1, -1));

        jPasswordContNuevConf.setForeground(new java.awt.Color(204, 204, 204));
        jPasswordContNuevConf.setText("********");
        jPasswordContNuevConf.setBorder(null);
        jPasswordContNuevConf.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPasswordContNuevConfMousePressed(evt);
            }
        });
        Fondo.add(jPasswordContNuevConf, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 490, 340, -1));

        CONFIRMARVERCONTNUEVA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/ver_32px.png"))); // NOI18N
        CONFIRMARVERCONTNUEVA.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        CONFIRMARVERCONTNUEVA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CONFIRMARVERCONTNUEVAMouseClicked(evt);
            }
        });
        Fondo.add(CONFIRMARVERCONTNUEVA, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 480, -1, -1));

        CONFIRMAROCULTARCONTNUEVA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/ocultar_32px.png"))); // NOI18N
        CONFIRMAROCULTARCONTNUEVA.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        CONFIRMAROCULTARCONTNUEVA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CONFIRMAROCULTARCONTNUEVAMouseClicked(evt);
            }
        });
        Fondo.add(CONFIRMAROCULTARCONTNUEVA, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 480, -1, -1));

        jSeparator4.setForeground(new java.awt.Color(0, 0, 0));
        Fondo.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 420, 370, 20));

        jButtonEnviar.setBackground(new java.awt.Color(51, 51, 51));
        jButtonEnviar.setFont(new java.awt.Font("Roboto Condensed", 0, 18)); // NOI18N
        jButtonEnviar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonEnviar.setText("Enviar");
        jButtonEnviar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonEnviar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEnviarActionPerformed(evt);
            }
        });
        Fondo.add(jButtonEnviar, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 310, 120, 40));

        jPanelMENU.setBackground(new java.awt.Color(255, 255, 255));
        jPanelMENU.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jPanelMENUMouseDragged(evt);
            }
        });
        jPanelMENU.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPanelMENUMousePressed(evt);
            }
        });

        jPanelSalir.setBackground(new java.awt.Color(255, 255, 255));
        jPanelSalir.setPreferredSize(new java.awt.Dimension(40, 40));

        jLabelX.setBackground(new java.awt.Color(255, 255, 255));
        jLabelX.setFont(new java.awt.Font("Roboto Light", 1, 18)); // NOI18N
        jLabelX.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelX.setText("X");
        jLabelX.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelX.setPreferredSize(new java.awt.Dimension(40, 40));
        jLabelX.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelXMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabelXMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabelXMouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanelSalirLayout = new javax.swing.GroupLayout(jPanelSalir);
        jPanelSalir.setLayout(jPanelSalirLayout);
        jPanelSalirLayout.setHorizontalGroup(
            jPanelSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
            .addGroup(jPanelSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanelSalirLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabelX, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanelSalirLayout.setVerticalGroup(
            jPanelSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(jPanelSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanelSalirLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabelX, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout jPanelMENULayout = new javax.swing.GroupLayout(jPanelMENU);
        jPanelMENU.setLayout(jPanelMENULayout);
        jPanelMENULayout.setHorizontalGroup(
            jPanelMENULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelMENULayout.createSequentialGroup()
                .addGap(0, 520, Short.MAX_VALUE)
                .addComponent(jPanelSalir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanelMENULayout.setVerticalGroup(
            jPanelMENULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanelSalir, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        Fondo.add(jPanelMENU, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 560, 30));

        jSeparator5.setForeground(new java.awt.Color(0, 0, 0));
        Fondo.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 560, 20));

        INICIARSESION.setFont(new java.awt.Font("Roboto Black", 1, 24)); // NOI18N
        INICIARSESION.setForeground(new java.awt.Color(102, 102, 102));
        INICIARSESION.setText("Restablecer Contraseña");
        Fondo.add(INICIARSESION, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 70, -1, -1));

        lblErrorDniIncorrecto.setFont(new java.awt.Font("Roboto Condensed", 0, 12)); // NOI18N
        lblErrorDniIncorrecto.setForeground(new java.awt.Color(255, 0, 0));
        lblErrorDniIncorrecto.setText("*No se encontro el dni del usuario*");
        Fondo.add(lblErrorDniIncorrecto, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 270, -1, 20));

        jSeparator6.setForeground(new java.awt.Color(0, 0, 0));
        Fondo.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 190, 370, 20));

        lblErrorUsuarioIncorrecto.setFont(new java.awt.Font("Roboto Condensed", 0, 12)); // NOI18N
        lblErrorUsuarioIncorrecto.setForeground(new java.awt.Color(255, 0, 0));
        lblErrorUsuarioIncorrecto.setText("*No se encontro el nombre del usuario*");
        Fondo.add(lblErrorUsuarioIncorrecto, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 190, -1, 20));

        lblErrorUsuarioVacio.setFont(new java.awt.Font("Roboto Condensed", 0, 12)); // NOI18N
        lblErrorUsuarioVacio.setForeground(new java.awt.Color(255, 0, 0));
        lblErrorUsuarioVacio.setText("*El nombre de usuario no puede estar vacio*");
        Fondo.add(lblErrorUsuarioVacio, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 190, -1, 20));

        lblErrorDniVacio.setFont(new java.awt.Font("Roboto Condensed", 0, 12)); // NOI18N
        lblErrorDniVacio.setForeground(new java.awt.Color(255, 0, 0));
        lblErrorDniVacio.setText("*El dni del usuario no puede estar vacio*");
        Fondo.add(lblErrorDniVacio, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 270, -1, 20));

        labelContraseñaVacioNueva.setFont(new java.awt.Font("Roboto Condensed", 0, 12)); // NOI18N
        labelContraseñaVacioNueva.setForeground(new java.awt.Color(255, 0, 0));
        labelContraseñaVacioNueva.setText("*Contraseña Vacia*");
        Fondo.add(labelContraseñaVacioNueva, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 420, -1, 20));

        labelContraseñaVacioConfirmacion.setFont(new java.awt.Font("Roboto Condensed", 0, 12)); // NOI18N
        labelContraseñaVacioConfirmacion.setForeground(new java.awt.Color(255, 0, 0));
        labelContraseñaVacioConfirmacion.setText("*Contraseña Vacia*");
        Fondo.add(labelContraseñaVacioConfirmacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 510, -1, 20));

        labelContraseñaNoCoincide.setFont(new java.awt.Font("Roboto Condensed", 0, 12)); // NOI18N
        labelContraseñaNoCoincide.setForeground(new java.awt.Color(255, 0, 0));
        labelContraseñaNoCoincide.setText("*La contraseña no coincide*");
        Fondo.add(labelContraseñaNoCoincide, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 510, -1, 20));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Fondo, javax.swing.GroupLayout.PREFERRED_SIZE, 558, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, 624, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextNombredeUsuarioRecuperarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextNombredeUsuarioRecuperarMousePressed
        if (jTextNombredeUsuarioRecuperar.getText().equals("Ingrese su nombre de usuario")) {
            jTextNombredeUsuarioRecuperar.setText("");
            jTextNombredeUsuarioRecuperar.setForeground(Color.black);

        }
        if (jTextDni.getText().isEmpty()) {
            jTextDni.setText("Ingrese su dni");
            jTextDni.setForeground(Color.gray);

        }
    }//GEN-LAST:event_jTextNombredeUsuarioRecuperarMousePressed

    private void jTextNombredeUsuarioRecuperarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextNombredeUsuarioRecuperarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextNombredeUsuarioRecuperarActionPerformed

    private void jTextDniMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextDniMousePressed
        if (jTextDni.getText().equals("Ingrese su dni")) {
            jTextDni.setText("");
            jTextDni.setForeground(Color.black);

        }
        if (jTextNombredeUsuarioRecuperar.getText().isEmpty()) {
            jTextNombredeUsuarioRecuperar.setText("Ingrese su nombre de usuario");
            jTextNombredeUsuarioRecuperar.setForeground(Color.gray);

        }
    }//GEN-LAST:event_jTextDniMousePressed

    private void jTextDniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextDniActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextDniActionPerformed

    private void jButtonGuardarysalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGuardarysalirActionPerformed

        this.getRootPane().requestFocus();  // Quita el foco de los campos de texto

        labelContraseñaVacioNueva.setVisible(false);
        labelContraseñaVacioConfirmacion.setVisible(false);
        labelContraseñaNoCoincide.setVisible(false);
        reiniciarCamposContraseñaSiVacios();
        VERCONTNUEVA.setVisible(true);
        CONFIRMARVERCONTNUEVA.setVisible(true);

        OCULTARCONTNUEVA.setVisible(false);
        CONFIRMAROCULTARCONTNUEVA.setVisible(false);
        
        jPasswordContNueva.setEchoChar('*');
        jPasswordContNuevConf.setEchoChar('*');

        
        String nuevaContraseña = String.valueOf(jPasswordContNueva.getPassword());
        String confirmacion = String.valueOf(jPasswordContNuevConf.getPassword());
      
        boolean hayError = false;

        if (nuevaContraseña.isEmpty()|| nuevaContraseña.equals("********")) {
            labelContraseñaVacioNueva.setVisible(true);
            hayError = true;
        }

        if (confirmacion.isEmpty() || confirmacion.equals("********")) {
            labelContraseñaVacioConfirmacion.setVisible(true);
            hayError = true;

        }
        if (!hayError && !nuevaContraseña.equals(confirmacion)) {
            labelContraseñaNoCoincide.setVisible(true);
            hayError = true;

        }

     
        if (hayError) {
            return; // Si hay errores, no continúa
        }
   
        // Actualizar en BD
        String dni = jTextDni.getText().trim();
        if (loginParent.login.actualizarContraseña(dni, nuevaContraseña)) {
            JOptionPane.showMessageDialog(this, "¡Contraseña actualizada!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Error al guardar la contraseña.", "Error", JOptionPane.ERROR_MESSAGE);
        }

        jPasswordContNueva.setEditable(false);
        jPasswordContNuevConf.setEditable(false);

        // Desactivar botón Guardar
        jButtonGuardarysalir.setEnabled(false);


    }//GEN-LAST:event_jButtonGuardarysalirActionPerformed

    private void jPasswordContNuevaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPasswordContNuevaMousePressed
        if (String.valueOf(jPasswordContNueva.getPassword()).equals("********")) {
            jPasswordContNueva.setText("");
            jPasswordContNueva.setForeground(Color.black);
        }
        if (String.valueOf(jPasswordContNuevConf.getPassword()).isEmpty()) {
            jPasswordContNuevConf.setText("********");
            jPasswordContNuevConf.setForeground(Color.gray);
        }
    }//GEN-LAST:event_jPasswordContNuevaMousePressed

    // Método para reiniciar campos vacíos a placeholders
        private void reiniciarCamposContraseñaSiVacios() {
        if (String.valueOf(jPasswordContNueva.getPassword()).isEmpty()) {
            jPasswordContNueva.setText("********");
            jPasswordContNueva.setForeground(Color.GRAY);
            jPasswordContNueva.setEchoChar((char) 0);
            VERCONTNUEVA.setVisible(true);
            OCULTARCONTNUEVA.setVisible(false);
        }

        if (String.valueOf(jPasswordContNuevConf.getPassword()).isEmpty()) {
            jPasswordContNuevConf.setText("********");
            jPasswordContNuevConf.setForeground(Color.GRAY);
            jPasswordContNuevConf.setEchoChar((char) 0);
            CONFIRMARVERCONTNUEVA.setVisible(true);
            CONFIRMAROCULTARCONTNUEVA.setVisible(false);
        }
    }

    private void VERCONTNUEVAMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VERCONTNUEVAMouseClicked
       VERCONTNUEVA.setVisible(false);
        OCULTARCONTNUEVA.setVisible(true);
        jPasswordContNueva.setEchoChar((char) 0);
    }//GEN-LAST:event_VERCONTNUEVAMouseClicked

    private void OCULTARCONTNUEVAMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OCULTARCONTNUEVAMouseClicked
      VERCONTNUEVA.setVisible(true);
        OCULTARCONTNUEVA.setVisible(false);
        jPasswordContNueva.setEchoChar('*');
    }//GEN-LAST:event_OCULTARCONTNUEVAMouseClicked

    private void jPasswordContNuevConfMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPasswordContNuevConfMousePressed
       if (String.valueOf(jPasswordContNuevConf.getPassword()).equals("********")) {
            jPasswordContNuevConf.setText("");
            jPasswordContNuevConf.setForeground(Color.black);
        }
        if (String.valueOf(jPasswordContNueva.getPassword()).isEmpty()) {
            jPasswordContNueva.setText("********");
            jPasswordContNueva.setForeground(Color.gray);
        }
    }//GEN-LAST:event_jPasswordContNuevConfMousePressed

    private void CONFIRMARVERCONTNUEVAMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CONFIRMARVERCONTNUEVAMouseClicked
        CONFIRMARVERCONTNUEVA.setVisible(false);
        CONFIRMAROCULTARCONTNUEVA.setVisible(true);
        jPasswordContNuevConf.setEchoChar((char) 0);
    }//GEN-LAST:event_CONFIRMARVERCONTNUEVAMouseClicked

    private void CONFIRMAROCULTARCONTNUEVAMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CONFIRMAROCULTARCONTNUEVAMouseClicked
        CONFIRMARVERCONTNUEVA.setVisible(true);
        CONFIRMAROCULTARCONTNUEVA.setVisible(false);
        jPasswordContNuevConf.setEchoChar('*');
    }//GEN-LAST:event_CONFIRMAROCULTARCONTNUEVAMouseClicked

    private void jButtonEnviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEnviarActionPerformed
        this.getRootPane().requestFocus();  // Quita el foco de los campos de texto
        ocultarTodosLosErrores(); // Oculta todos los errores al inicio

        String nombreCompleto = jTextNombredeUsuarioRecuperar.getText().trim();
        String dni = jTextDni.getText().trim();

        String[] partesNombre = nombreCompleto.split(" ", 2);
        String nombre = partesNombre.length > 0 ? partesNombre[0] : "";
        String apellido = partesNombre.length > 1 ? partesNombre[1] : "";

        boolean hayErrores = false;

        // Validar usuario vacío o texto por defecto
        if (nombreCompleto.isEmpty() || nombreCompleto.equals("Ingrese su nombre de usuario")) {
            mostrarErrorUsuarioVacio();
            hayErrores = true;
        }

        // Validar DNI vacío o texto por defecto
        if (dni.isEmpty() || dni.equals("Ingrese su dni")) {
            mostrarErrorDniVacio();
            hayErrores = true;
        }
        
      

        if (hayErrores) {
            return; // No continuar si el DNI no tiene formato válido
        }

        // Validar credenciales con la base de datos
        boolean credencialesValidas = loginParent.login.validarNombreYDni(nombre, apellido, dni);

        if (!credencialesValidas) {
            // Mostrar errores apropiados
            boolean usuarioExiste = loginParent.login.existeUsuario(nombreCompleto);
            boolean dniValido = false; // Necesitarías implementar un método para validar solo el DNI

            if (!usuarioExiste && !dniValido) {
                // Ambos están mal
                mostrarErrorUsuarioIncorrecto();
                mostrarErrorDniIncorrecto();
            } else if (usuarioExiste && !dniValido) {
                // Solo DNI incorrecto
                mostrarErrorDniIncorrecto();
            } else {
                // Solo usuario incorrecto
                mostrarErrorUsuarioIncorrecto();
            }
            return;
        }

        // Si las credenciales son válidas, mostrar campos de contraseña
        CONTRASEÑANUEVA.setVisible(true);
        jPasswordContNueva.setVisible(true);
        jSeparator4.setVisible(true);
        CONFIRMARCONTRASEÑA.setVisible(true);
        jPasswordContNuevConf.setVisible(true);
        jSeparator1.setVisible(true);
        jButtonGuardarysalir.setVisible(true);
        VERCONTNUEVA.setVisible(true);
       
        CONFIRMARVERCONTNUEVA.setVisible(true);

        // Deshabilitar campos de usuario y DNI
        jButtonEnviar.setEnabled(false);
        jTextNombredeUsuarioRecuperar.setEditable(false);
        jTextDni.setEditable(false);
                
    }//GEN-LAST:event_jButtonEnviarActionPerformed

    private void jLabelXMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelXMouseClicked
        this.dispose(); 
    }//GEN-LAST:event_jLabelXMouseClicked

    private void jLabelXMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelXMouseEntered
        jPanelSalir.setBackground(Color.red);
        jLabelX.setForeground(Color.white);
    }//GEN-LAST:event_jLabelXMouseEntered

    private void jLabelXMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelXMouseExited
        jPanelSalir.setBackground(Color.white);
        jLabelX.setForeground(Color.black);
    }//GEN-LAST:event_jLabelXMouseExited

    private void jPasswordContNuevaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordContNuevaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jPasswordContNuevaActionPerformed

    private void jPanelMENUMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanelMENUMousePressed
        xMouse= evt.getX();
        yMouse= evt.getY();  
    }//GEN-LAST:event_jPanelMENUMousePressed

    private void jPanelMENUMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanelMENUMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_jPanelMENUMouseDragged


    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel CONFIRMARCONTRASEÑA;
    private javax.swing.JLabel CONFIRMAROCULTARCONTNUEVA;
    private javax.swing.JLabel CONFIRMARVERCONTNUEVA;
    private javax.swing.JLabel CONTRASEÑANUEVA;
    private javax.swing.JLabel DNI;
    private javax.swing.JPanel Fondo;
    private javax.swing.JLabel INICIARSESION;
    private javax.swing.JLabel NOMBRE;
    private javax.swing.JLabel OCULTARCONTNUEVA;
    private javax.swing.JLabel VERCONTNUEVA;
    private javax.swing.JButton jButtonEnviar;
    private javax.swing.JButton jButtonGuardarysalir;
    private javax.swing.JLabel jLabelX;
    private javax.swing.JPanel jPanelMENU;
    private javax.swing.JPanel jPanelSalir;
    private javax.swing.JPasswordField jPasswordContNuevConf;
    private javax.swing.JPasswordField jPasswordContNueva;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JTextField jTextDni;
    private javax.swing.JTextField jTextNombredeUsuarioRecuperar;
    private javax.swing.JLabel labelContraseñaNoCoincide;
    private javax.swing.JLabel labelContraseñaVacioConfirmacion;
    private javax.swing.JLabel labelContraseñaVacioNueva;
    private javax.swing.JLabel lblErrorDniIncorrecto;
    private javax.swing.JLabel lblErrorDniVacio;
    private javax.swing.JLabel lblErrorUsuarioIncorrecto;
    private javax.swing.JLabel lblErrorUsuarioVacio;
    // End of variables declaration//GEN-END:variables
}
