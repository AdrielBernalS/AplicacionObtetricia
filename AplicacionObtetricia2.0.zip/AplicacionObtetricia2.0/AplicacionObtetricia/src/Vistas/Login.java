
package Vistas;
import Controlador.LoginDAO;
import Controlador.login;
import com.raven.main.Main;
import com.raven.main.Main.SistemaPerfil;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import javax.swing.Timer;

public class Login extends javax.swing.JFrame {

    int xMouse, yMouse;
    private javax.swing.Timer timer;
    private final int TIEMPO_LIMITE_SEGUNDOS = 5 * 60; // 5 minutos en segundos (300s)
    private int tiempoRestante = TIEMPO_LIMITE_SEGUNDOS;

    private int intentosFallidos = 0;
    private final int MAX_INTENTOS = 3;

    login lg = new login();
    LoginDAO login = new LoginDAO();
    

    public Login() {
        initComponents();
        setSize(816, 490);  // Establece el tamaño de la ventana a 400x300 píxeles
        setLocationRelativeTo(null);  // Esto centra la ventana en la pantalla
        jPanelMENU.setFocusable(true);
        this.OCULTAR.setVisible(false);
        ocultarTodosLosErrores();

        timer = new Timer(1000, e -> {
            tiempoRestante--;

            // Formatea minutos:segundos (ej: 04:59)
            int minutos = tiempoRestante / 60;
            int segundos = tiempoRestante % 60;
            String tiempoFormateado = String.format("%02d:%02d", minutos, segundos);
            lblContadorTiempo.setText("Tiempo: " + tiempoFormateado);

            // Cambia a rojo los últimos 30 segundos
            if (tiempoRestante <= 30) {
                lblContadorTiempo.setForeground(Color.RED);
                if (tiempoRestante == 30) {
                    Toolkit.getDefaultToolkit().beep(); // Alerta
                }
            }

            // Cierra al llegar a 00:00
            if (tiempoRestante <= 0) {
                timer.stop();
                Toolkit.getDefaultToolkit().beep();
                JOptionPane.showMessageDialog(this, "Tiempo agotado. Sesión cerrada.");
                this.dispose();
            }
        });
        timer.start();

        txtUsuario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                reiniciarContador();
            }
        });

        txtPassword.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                reiniciarContador();
            }
        });

        // Listener para el label "¿Olvidaste tu contraseña?"
        jLabelOlvidecontraseña.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                reiniciarIntentos();
                reiniciarContador();
                
            }
        });

        txtUsuario.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                if (txtUsuario.getText().equals("Ingrese su nombre de usuario")) {
                    txtUsuario.setText("");
                    txtUsuario.setForeground(Color.black);
                }
            }

            public void focusLost(java.awt.event.FocusEvent evt) {
                if (txtUsuario.getText().isEmpty()) {
                    txtUsuario.setText("Ingrese su nombre de usuario");
                    txtUsuario.setForeground(Color.gray);
                }
            }
        });

        txtPassword.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                if (String.valueOf(txtPassword.getPassword()).equals("********")) {
                    txtPassword.setText("");
                    txtPassword.setForeground(Color.black);
                    txtPassword.setEchoChar('*');
                }
            }

            public void focusLost(java.awt.event.FocusEvent evt) {
                if (String.valueOf(txtPassword.getPassword()).isEmpty()) {
                    txtPassword.setText("********");
                    txtPassword.setForeground(Color.gray);
                    txtPassword.setEchoChar((char) 0);
                }
            }
        });

        jButtonIngresar.addActionListener(e -> reiniciarContador());
        
        
        txtUsuario.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    // Llamar al método de validación cuando se presiona Enter
                    txtPassword.requestFocus();
                }
            }
        });
        
        txtPassword.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    // Llamar al método de validación cuando se presiona Enter
                    validar();
                }
            }
        });

        // Al final del constructor, agrega:
        if (lblIntentosRestantes != null) {
            lblIntentosRestantes.setText("Intentos restantes: " + MAX_INTENTOS);
        }
        
        
    }

    // Método para reiniciar:
    private void reiniciarContador() {
        tiempoRestante = TIEMPO_LIMITE_SEGUNDOS; // Reinicia a 5 minutos
        int minutos = tiempoRestante / 60;
        int segundos = tiempoRestante % 60;
        lblContadorTiempo.setText(String.format("Tiempo: %02d:%02d", minutos, segundos));
        lblContadorTiempo.setForeground(Color.black); // Restaura color original
    }
    
    
    
    public void validar() {
        
        ocultarTodosLosErrores();
        
        String usuario = txtUsuario.getText();
        String contraseña = String.valueOf(txtPassword.getPassword());
        boolean hayErrores = false;

        // Validar usuario vacío o texto por defecto
        if (usuario.isEmpty() || usuario.equals("Ingrese su nombre de usuario")) {
            lblErrorUsuarioVacio.setVisible(true);
            hayErrores = true;
        }

        // Validar contraseña vacía o texto por defecto
        if (contraseña.isEmpty() || contraseña.equals("********")) {
            lblErrorPasswordVacio.setVisible(true);
            hayErrores = true;
        }

        if (hayErrores) {
            return;
        }

        // Validar credenciales con la base de datos
        lg = login.log(usuario, contraseña, "", "");

        if (lg == null || lg.getUsuario() == null) {

            intentosFallidos++; // Incrementar intentos fallidos

            // Actualizar el JLabel de intentos (debes agregarlo en tu diseño)
            lblIntentosRestantes.setText("Intentos restantes: " + (MAX_INTENTOS - intentosFallidos));

            if ((MAX_INTENTOS - intentosFallidos) <= 1) {
                lblIntentosRestantes.setForeground(Color.RED);
            } else {
                lblIntentosRestantes.setForeground(Color.BLACK);
            }
            
            if ((MAX_INTENTOS - intentosFallidos) == 1) {
                Toolkit.getDefaultToolkit().beep();
            }
            if (intentosFallidos >= MAX_INTENTOS) {
                Toolkit.getDefaultToolkit().beep();
                JOptionPane.showMessageDialog(this,
                        "Límite de intentos excedido. La aplicación se cerrará.",
                        "Acceso bloqueado",
                        JOptionPane.ERROR_MESSAGE);
                System.exit(0);
            }

            boolean usuarioExiste = login.existeUsuario(txtUsuario.getText()); // Necesitarás implementar este método
            boolean contraseñaValida = false;
            if (!usuarioExiste && !contraseñaValida) {
                // Ambos están mal
                lblErrorUsuarioIncorrecto.setVisible(true);
                lblErrorPasswordIncorrecto.setVisible(true);
            } else if (usuarioExiste && !contraseñaValida) {
                // Solo contraseña incorrecta
                lblErrorPasswordIncorrecto.setVisible(true);
                lblErrorUsuarioIncorrecto.setVisible(false);
            } else {
                // Solo usuario incorrecto
                lblErrorUsuarioIncorrecto.setVisible(true);
                lblErrorPasswordIncorrecto.setVisible(false);
            }

            txtPassword.requestFocus();
        } else {

            intentosFallidos = 0;
            lblIntentosRestantes.setText("");

            JOptionPane.showMessageDialog(
                    null,
                    "<html><b><font size='4' color='#2E86C1'>¡Bienvenido!</font></b><br><br>"
                    + lg.getNombre() + " " + lg.getApellido() + "</html>",
                    "Acceso concedido",
                    JOptionPane.INFORMATION_MESSAGE
            );

            if (lg.getFoto() != null) {
                SistemaPerfil.setFotoPerfil(lg.getFoto());
            }
            
            // Login exitoso
            if (timer != null && timer.isRunning()) {
                timer.stop(); // 🔴 Detener el contador porque ya inició sesión
            }
            Main menu = new Main();
            menu.setVisible(true);
            dispose();
        }
    }

    private void reiniciarIntentos() {
        intentosFallidos = 0;
        lblIntentosRestantes.setText("Intentos restantes: " + MAX_INTENTOS);
        lblIntentosRestantes.setForeground(Color.BLACK); // Restaurar color original
    }

    private void ocultarTodosLosErrores() {
        lblErrorUsuarioVacio.setVisible(false);
        lblErrorUsuarioIncorrecto.setVisible(false);
        lblErrorPasswordVacio.setVisible(false);
        lblErrorPasswordIncorrecto.setVisible(false);
    }

    private void ocultarErroresUsuario() {
        lblErrorUsuarioVacio.setVisible(false);
        lblErrorUsuarioIncorrecto.setVisible(false);
    }

    private void ocultarErroresPassword() {
        lblErrorPasswordVacio.setVisible(false);
        lblErrorPasswordIncorrecto.setVisible(false);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        FONDO = new javax.swing.JPanel();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        IMAGEN_ENFERMERA = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabelOlvidecontraseña = new javax.swing.JLabel();
        IMAGEN_FONDOAZUL = new javax.swing.JLabel();
        jPanelMENU = new javax.swing.JPanel();
        jPanelSalir = new javax.swing.JPanel();
        jLabelX = new javax.swing.JLabel();
        INICIARSESION = new javax.swing.JLabel();
        USUARIO = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        txtUsuario = new javax.swing.JTextField();
        CONTRASEÑA = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        txtPassword = new javax.swing.JPasswordField();
        jButtonIngresar = new javax.swing.JButton();
        jSeparator4 = new javax.swing.JSeparator();
        VER = new javax.swing.JLabel();
        OCULTAR = new javax.swing.JLabel();
        lblErrorPasswordVacio = new javax.swing.JLabel();
        lblErrorUsuarioIncorrecto = new javax.swing.JLabel();
        lblErrorUsuarioVacio = new javax.swing.JLabel();
        lblErrorPasswordIncorrecto = new javax.swing.JLabel();
        lblIntentosRestantes = new javax.swing.JLabel();
        lblContadorTiempo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        setResizable(false);

        FONDO.setBackground(new java.awt.Color(255, 255, 255));
        FONDO.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jSeparator3.setForeground(new java.awt.Color(0, 0, 0));
        FONDO.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 73, 190, 10));

        jLabel3.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        jLabel3.setText("DPTO OBSTETRICIA");
        FONDO.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, -1));

        jLabel2.setFont(new java.awt.Font("Roboto Black", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 51, 51));
        jLabel2.setText("PROGRAMA");
        FONDO.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, -1, -1));

        IMAGEN_ENFERMERA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/pngegg.png"))); // NOI18N
        FONDO.add(IMAGEN_ENFERMERA, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 160, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/ministerio-de-salud-del-peru-seeklogo.png"))); // NOI18N
        FONDO.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 90, -1, -1));

        jLabelOlvidecontraseña.setFont(new java.awt.Font("Roboto Condensed", 0, 12)); // NOI18N
        jLabelOlvidecontraseña.setForeground(new java.awt.Color(153, 153, 153));
        jLabelOlvidecontraseña.setText("¿Olvidaste tu contraseña?");
        jLabelOlvidecontraseña.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelOlvidecontraseña.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelOlvidecontraseñaMouseClicked(evt);
            }
        });
        FONDO.add(jLabelOlvidecontraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 350, -1, -1));

        IMAGEN_FONDOAZUL.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/city.png"))); // NOI18N
        FONDO.add(IMAGEN_FONDOAZUL, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 300, 490));

        jPanelMENU.setBackground(new java.awt.Color(255, 255, 255));
        jPanelMENU.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jPanelMENUMouseDragged(evt);
            }
        });
        jPanelMENU.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPanelMENUMousePressed(evt);
            }
        });

        jPanelSalir.setBackground(new java.awt.Color(255, 255, 255));
        jPanelSalir.setPreferredSize(new java.awt.Dimension(40, 40));

        jLabelX.setBackground(new java.awt.Color(255, 255, 255));
        jLabelX.setFont(new java.awt.Font("Roboto Light", 1, 18)); // NOI18N
        jLabelX.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelX.setText("X");
        jLabelX.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelX.setPreferredSize(new java.awt.Dimension(40, 40));
        jLabelX.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelXMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabelXMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabelXMouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanelSalirLayout = new javax.swing.GroupLayout(jPanelSalir);
        jPanelSalir.setLayout(jPanelSalirLayout);
        jPanelSalirLayout.setHorizontalGroup(
            jPanelSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
            .addGroup(jPanelSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanelSalirLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabelX, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanelSalirLayout.setVerticalGroup(
            jPanelSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
            .addGroup(jPanelSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanelSalirLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabelX, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout jPanelMENULayout = new javax.swing.GroupLayout(jPanelMENU);
        jPanelMENU.setLayout(jPanelMENULayout);
        jPanelMENULayout.setHorizontalGroup(
            jPanelMENULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelMENULayout.createSequentialGroup()
                .addContainerGap(771, Short.MAX_VALUE)
                .addComponent(jPanelSalir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanelMENULayout.setVerticalGroup(
            jPanelMENULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanelSalir, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        FONDO.add(jPanelMENU, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 820, 30));

        INICIARSESION.setFont(new java.awt.Font("Roboto Black", 1, 24)); // NOI18N
        INICIARSESION.setForeground(new java.awt.Color(102, 102, 102));
        INICIARSESION.setText("INICIAR SESIÓN");
        FONDO.add(INICIARSESION, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 110, -1, -1));

        USUARIO.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        USUARIO.setForeground(new java.awt.Color(51, 51, 51));
        USUARIO.setText("USUARIO");
        FONDO.add(USUARIO, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 200, -1, -1));

        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));
        FONDO.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 250, 370, 20));

        txtUsuario.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        txtUsuario.setForeground(new java.awt.Color(204, 204, 204));
        txtUsuario.setText("Ingrese su nombre de usuario");
        txtUsuario.setBorder(null);
        txtUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtUsuarioMousePressed(evt);
            }
        });
        FONDO.add(txtUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 230, 300, -1));

        CONTRASEÑA.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        CONTRASEÑA.setForeground(new java.awt.Color(51, 51, 51));
        CONTRASEÑA.setText("CONTRASEÑA");
        FONDO.add(CONTRASEÑA, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 290, -1, -1));

        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));
        FONDO.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 340, 370, 20));

        txtPassword.setForeground(new java.awt.Color(204, 204, 204));
        txtPassword.setText("********");
        txtPassword.setBorder(null);
        txtPassword.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                txtPasswordMousePressed(evt);
            }
        });
        FONDO.add(txtPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 320, 340, -1));

        jButtonIngresar.setBackground(new java.awt.Color(204, 204, 204));
        jButtonIngresar.setFont(new java.awt.Font("Roboto Condensed", 0, 18)); // NOI18N
        jButtonIngresar.setText("Ingresar");
        jButtonIngresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonIngresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonIngresarActionPerformed(evt);
            }
        });
        FONDO.add(jButtonIngresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 390, 120, 40));

        jSeparator4.setForeground(new java.awt.Color(0, 0, 0));
        FONDO.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 30, 510, 20));

        VER.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/ver_32px.png"))); // NOI18N
        VER.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        VER.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                VERMouseClicked(evt);
            }
        });
        FONDO.add(VER, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 310, -1, -1));

        OCULTAR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/ocultar_32px.png"))); // NOI18N
        OCULTAR.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        OCULTAR.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OCULTARMouseClicked(evt);
            }
        });
        FONDO.add(OCULTAR, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 310, -1, -1));

        lblErrorPasswordVacio.setFont(new java.awt.Font("Roboto Condensed", 0, 12)); // NOI18N
        lblErrorPasswordVacio.setForeground(new java.awt.Color(255, 0, 0));
        lblErrorPasswordVacio.setText("*Ingrese una contraseña*");
        FONDO.add(lblErrorPasswordVacio, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 350, -1, -1));

        lblErrorUsuarioIncorrecto.setFont(new java.awt.Font("Roboto Condensed", 0, 12)); // NOI18N
        lblErrorUsuarioIncorrecto.setForeground(new java.awt.Color(255, 0, 0));
        lblErrorUsuarioIncorrecto.setText("*Nombre de usuario incorrecto*");
        FONDO.add(lblErrorUsuarioIncorrecto, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 260, -1, -1));

        lblErrorUsuarioVacio.setFont(new java.awt.Font("Roboto Condensed", 0, 12)); // NOI18N
        lblErrorUsuarioVacio.setForeground(new java.awt.Color(255, 0, 0));
        lblErrorUsuarioVacio.setText("*El nombre de usuario no puede estar vacio*");
        FONDO.add(lblErrorUsuarioVacio, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 260, -1, -1));

        lblErrorPasswordIncorrecto.setFont(new java.awt.Font("Roboto Condensed", 0, 12)); // NOI18N
        lblErrorPasswordIncorrecto.setForeground(new java.awt.Color(255, 0, 0));
        lblErrorPasswordIncorrecto.setText("*Contraseña incorrecta*");
        FONDO.add(lblErrorPasswordIncorrecto, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 350, -1, -1));

        lblIntentosRestantes.setFont(new java.awt.Font("Roboto", 1, 12)); // NOI18N
        lblIntentosRestantes.setText("Intentos restantes: 5");
        FONDO.add(lblIntentosRestantes, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 450, -1, -1));

        lblContadorTiempo.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        lblContadorTiempo.setForeground(new java.awt.Color(51, 51, 51));
        lblContadorTiempo.setText("Tiempo: 05:00");
        FONDO.add(lblContadorTiempo, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 50, -1, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(FONDO, javax.swing.GroupLayout.PREFERRED_SIZE, 816, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(FONDO, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonIngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonIngresarActionPerformed
     validar();
     if (lg == null || lg.getUsuario() == null) {
        VER.setVisible(true);           // Muestra el botón "VER"
        OCULTAR.setVisible(false);      // Oculta el botón "OCULTAR"
        txtPassword.setEchoChar('*');   // Restaura los asteriscos
    }
     this.getRootPane().requestFocus();
    }//GEN-LAST:event_jButtonIngresarActionPerformed

    private void jPanelMENUMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanelMENUMousePressed
        xMouse= evt.getX();
        yMouse= evt.getY();        
    }//GEN-LAST:event_jPanelMENUMousePressed

    private void jPanelMENUMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanelMENUMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_jPanelMENUMouseDragged

    private void jLabelXMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelXMouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabelXMouseClicked

    private void jLabelXMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelXMouseEntered
        jPanelSalir.setBackground(Color.red);
        jLabelX.setForeground(Color.white);
    }//GEN-LAST:event_jLabelXMouseEntered

    private void jLabelXMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelXMouseExited
        jPanelSalir.setBackground(Color.white);
        jLabelX.setForeground(Color.black);

    }//GEN-LAST:event_jLabelXMouseExited

    private void txtUsuarioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtUsuarioMousePressed
        if (txtUsuario.getText().equals("Ingrese su nombre de usuario")) {          
            txtUsuario.setText("");
            txtUsuario.setForeground(Color.black);
               
        }
        if (String.valueOf(txtPassword.getPassword()).isEmpty()) {
            txtPassword.setText("********");
            txtPassword.setForeground(Color.gray);
        }
        ocultarErroresUsuario();
    }//GEN-LAST:event_txtUsuarioMousePressed

    private void txtPasswordMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtPasswordMousePressed
        if (String.valueOf(txtPassword.getPassword()).equals("********")) {
            txtPassword.setText("");
            txtPassword.setForeground(Color.black);
        }
        if (txtUsuario.getText().isEmpty()) {
            txtUsuario.setText("Ingrese su nombre de usuario");
            txtUsuario.setForeground(Color.gray);
        }
        ocultarErroresPassword();
    }//GEN-LAST:event_txtPasswordMousePressed

    private void VERMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VERMouseClicked
        VER.setVisible(false);
        OCULTAR.setVisible(true);
        txtPassword.setEchoChar((char)0);
    }//GEN-LAST:event_VERMouseClicked

    private void OCULTARMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OCULTARMouseClicked
        VER.setVisible(true);
        OCULTAR.setVisible(false);
        txtPassword.setEchoChar('*');
    }//GEN-LAST:event_OCULTARMouseClicked

    private void jLabelOlvidecontraseñaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelOlvidecontraseñaMouseClicked
        if (timer != null && timer.isRunning()) {
            timer.stop();
        }
        VER.setVisible(true);           // Muestra el botón "VER"
        OCULTAR.setVisible(false);      // Oculta el botón "OCULTAR"
        txtPassword.setEchoChar('*');
        // Limpiar campos y mensajes de error
        txtUsuario.setText("Ingrese su nombre de usuario");
        txtUsuario.setForeground(Color.GRAY);
        txtPassword.setText("********");
        txtPassword.setForeground(Color.GRAY);
        txtPassword.setEchoChar((char) 0);

        // Ocultar todos los errores
        ocultarTodosLosErrores();
        
        jPanelMENU.requestFocusInWindow();

        this.setVisible(false);
        RecuperarContraseña dialog = new RecuperarContraseña(this, true); // "this" es la ventana padre (Login)
        dialog.setVisible(true); // Muestra el diálogo (modal)
        this.setVisible(true); // Vuelve a mostrar el Login

        VER.setVisible(true);           // Muestra el botón "VER"
        OCULTAR.setVisible(false);      // Oculta el botón "OCULTAR"
        txtPassword.setEchoChar('*');   // Restaura asteriscos
        txtPassword.setText("********"); // Restaura placeholder
        txtPassword.setForeground(Color.GRAY);

    }//GEN-LAST:event_jLabelOlvidecontraseñaMouseClicked


    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel CONTRASEÑA;
    private javax.swing.JPanel FONDO;
    private javax.swing.JLabel IMAGEN_ENFERMERA;
    private javax.swing.JLabel IMAGEN_FONDOAZUL;
    private javax.swing.JLabel INICIARSESION;
    private javax.swing.JLabel OCULTAR;
    private javax.swing.JLabel USUARIO;
    private javax.swing.JLabel VER;
    private javax.swing.JButton jButtonIngresar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabelOlvidecontraseña;
    private javax.swing.JLabel jLabelX;
    private javax.swing.JPanel jPanelMENU;
    private javax.swing.JPanel jPanelSalir;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JLabel lblContadorTiempo;
    private javax.swing.JLabel lblErrorPasswordIncorrecto;
    private javax.swing.JLabel lblErrorPasswordVacio;
    private javax.swing.JLabel lblErrorUsuarioIncorrecto;
    private javax.swing.JLabel lblErrorUsuarioVacio;
    private javax.swing.JLabel lblIntentosRestantes;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
