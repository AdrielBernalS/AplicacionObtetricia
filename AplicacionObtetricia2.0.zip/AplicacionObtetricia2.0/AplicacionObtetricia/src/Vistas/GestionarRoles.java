
package Vistas;
    
import Controlador.RolDao;
import Controlador.rol;
import com.formdev.flatlaf.FlatClientProperties;
import com.mysql.cj.xdevapi.Table;
import com.raven.swing.ScrollBar;
import java.awt.Color;
import java.awt.Component;
import java.util.List;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import com.raven.swing.TableGradientCell;
import com.raven.swing.TableHeader;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.KeyboardFocusManager;
import java.awt.Window;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.BorderFactory;
import javax.swing.UIManager;
import java.sql.SQLException;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableColumn;

public class GestionarRoles extends javax.swing.JPanel {
        int xMouse, yMouse;
    private int idRolSeleccionado = -1; // Esto va al inicio de tu clase
    private rol rolOriginalSeleccionado = null;


    private DefaultTableModel modelo;
    private RolDao rolDao; // Asumo que tienes esta clase para acceder a la BD

    public GestionarRoles() {
        initComponents();
        jLabelErrorNombre.setVisible(false); // Ocultar mensaje al iniciar
        jLabelErrorRolExistente.setVisible(false);
        jCheckBoxRoles.setText("Inactivo");
        jCheckBoxRoles.setFont(new Font("Roboto", Font.BOLD, 14));


        jCheckBoxRoles.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (jCheckBoxRoles.isSelected()) {
                    jCheckBoxRoles.setText("Activo");
                } else {
                    jCheckBoxRoles.setText("Inactivo");
                }
            }
        });
        
        

        // 1. Configuración básica de FlatLaf para la tabla
        UIManager.put("TableHeader.height", 28);
        UIManager.put("Table.rowHeight", 30);
        UIManager.put("Table.cellFocusColor", null);

        // 2. Configurar el renderizador del encabezado
        tableRoles.getTableHeader().setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                return new TableHeader(value != null ? value.toString() : "");
            }
        });

        // 3. Configuración específica de FlatLaf para la tabla
        tableRoles.putClientProperty(FlatClientProperties.STYLE, ""
                + "border:0,0,0,0,shade(@background,5%),,0;"
                + "selectionBackground:rgb(57,105,138);"
                + "selectionForeground:white;"
                + "cellFocusColor:null;");

        // 4. Configuración del scroll pane
        jScrollPane1.putClientProperty(FlatClientProperties.STYLE, ""
                + "border:3,0,3,0,$Table.background,10,10");
        jScrollPane1.getVerticalScrollBar().putClientProperty(FlatClientProperties.STYLE, ""
                + "hoverTrackColor:null");

        // 5. Configuración del panel contenedor
        PanelRoles.putClientProperty(FlatClientProperties.STYLE, ""
                + "border:1,1,1,1,$TableHeader.bottomSeparatorColor,,10;"
                + "unifiedBackground:false;");

        // 6. Configuración adicional de la tabla
        tableRoles.setShowGrid(false);
        tableRoles.setIntercellSpacing(new Dimension(0, 0));
        tableRoles.setRowHeight(30);
        tableRoles.setAutoCreateRowSorter(true);
    
        tableRoles.getTableHeader().setReorderingAllowed(false);

        ////////////////////////
        PanelRoles.setBackground(new java.awt.Color(250, 250, 250));
        PanelRoles.setOpaque(true);
        jTextNombre.setBackground(new Color(250, 250, 250));  // Fondo transparente
        jTextNombre.setOpaque(false);
        jScrollPane1.getViewport().setOpaque(true);
        jScrollPane1.getViewport().setBackground(new Color(250, 250, 250));

        // 1. Configurar el modelo de tabla con las columnas
        String[] columnNames = {"N°", "Nombre del Rol", "Estado", "idRol"}; // 4 columnas
        modelo = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Todas las celdas no editables
            }
        };
        tableRoles.setModel(modelo);    
        TableColumn columnaOculta = tableRoles.getColumnModel().getColumn(3);
        columnaOculta.setMinWidth(0);
        columnaOculta.setMaxWidth(0);
        columnaOculta.setPreferredWidth(0);

        // 2. Configurar el renderizador personalizado
        tableRoles.setDefaultRenderer(Object.class, new TableGradientCell());

        tableRoles.setShowGrid(true);
        tableRoles.setGridColor(Color.BLACK);
        tableRoles.setIntercellSpacing(new Dimension(1, 1));
        // 3. Configuraciones de estilo (las que tenías originalmente)
        PanelRoles.putClientProperty(FlatClientProperties.STYLE, ""
                + "border:1,1,1,1,$TableHeader.bottomSeparatorColor,,10");

        jScrollPane1.putClientProperty(FlatClientProperties.STYLE, ""
                + "border:3,0,3,0,$Table.background,10,10");
        jScrollPane1.getVerticalScrollBar().putClientProperty(FlatClientProperties.STYLE, ""
                + "hoverTrackColor:null");

        jScrollPane1.setVerticalScrollBar(new ScrollBar());
        jScrollPane1.setHorizontalScrollBar(new ScrollBar());

        // 4. Inicializar acceso a BD
        rolDao = new RolDao();

        // 5. Cargar datos desde BD
        cargarRolesDesdeBD();

        btnAgregar.setBackground(new Color(173, 216, 230)); 
        btnAgregar.setEffectColor(new Color(255, 69, 0));
        
        btnEditar.setBackground(new Color(173, 216, 230)); 
        btnEditar.setEffectColor(new Color(255, 69, 0));
        
        BtnEliminar.setBackground(new Color(173, 216, 230)); 
        BtnEliminar.setEffectColor(new Color(255, 69, 0));
  
        BtnVaciarDatos.setBackground(new Color(173, 216, 230));
        BtnVaciarDatos.setEffectColor(new Color(255, 69, 0));

        jTextNombre.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                if (jTextNombre.getText().equals("Ingrese el nombre del rol")) {
                    jTextNombre.setText("");
                    jTextNombre.setForeground(Color.BLACK);
                }
            }

            public void focusLost(java.awt.event.FocusEvent evt) {
                if (jTextNombre.getText().trim().isEmpty()) {
                    jTextNombre.setText("Ingrese el nombre del rol");
                    jTextNombre.setForeground(Color.GRAY);
                }
            }
        });

        SwingUtilities.invokeLater(() -> {
            btnAgregar.requestFocusInWindow(); // O el botón que prefieras
        });
    }


    private void cargarRolesDesdeBD() {
        modelo.setRowCount(0); // Limpiar tabla

        try {
            List<rol> listaRoles = rolDao.listarRoles();

            int n = 1;
            for (rol r : listaRoles) {
                String estado = r.getEstado() == 1 ? "Activo" : "Inactivo";
                modelo.addRow(new Object[]{
                    n++, // Asumo que tu clase rol tiene getId()
                    r.getDescripcion(),
                    estado,
                    r.getIdRol()

                });

            }
            TableColumn col = tableRoles.getColumnModel().getColumn(3);
            col.setMinWidth(0);
            col.setMaxWidth(0);
            col.setPreferredWidth(0);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al cargar roles: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private Runnable onCloseCallback;

    public void setOnCloseCallback(Runnable onCloseCallback) {
        this.onCloseCallback = onCloseCallback;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        PanelRoles = new javax.swing.JPanel();
        jLabelErrorRolExistente = new javax.swing.JLabel();
        jLabelErrorNombre = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextNombre = new javax.swing.JTextField();
        jSeparator2 = new javax.swing.JSeparator();
        jCheckBoxRoles = new com.raven.swing.JCheckBoxCustom();
        INICIARSESION = new javax.swing.JLabel();
        btnAgregar = new com.raven.swing.Button();
        btnEditar = new com.raven.swing.Button();
        BtnEliminar = new com.raven.swing.Button();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableRoles = new javax.swing.JTable();
        BtnVaciarDatos = new com.raven.swing.Button();
        jPanelMENU = new javax.swing.JPanel();
        jPanelSalir = new javax.swing.JPanel();
        jLabelX = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();

        setFocusable(false);

        PanelRoles.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelErrorRolExistente.setFont(new java.awt.Font("Roboto Condensed", 0, 12)); // NOI18N
        jLabelErrorRolExistente.setForeground(new java.awt.Color(255, 0, 0));
        jLabelErrorRolExistente.setText("*Rol existente*");
        PanelRoles.add(jLabelErrorRolExistente, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 120, -1, -1));

        jLabelErrorNombre.setFont(new java.awt.Font("Roboto Condensed", 0, 12)); // NOI18N
        jLabelErrorNombre.setForeground(new java.awt.Color(255, 0, 0));
        jLabelErrorNombre.setText("*El campo no puede estar vacío*");
        PanelRoles.add(jLabelErrorNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 120, -1, -1));

        jLabel8.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel8.setText("Nombre:");
        PanelRoles.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 90, -1, -1));

        jTextNombre.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        jTextNombre.setForeground(new java.awt.Color(204, 204, 204));
        jTextNombre.setText("Ingrese el nombre del rol");
        jTextNombre.setBorder(null);
        jTextNombre.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jTextNombreMousePressed(evt);
            }
        });
        jTextNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextNombreActionPerformed(evt);
            }
        });
        PanelRoles.add(jTextNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 90, 310, -1));

        jSeparator2.setForeground(new java.awt.Color(3, 155, 216));
        PanelRoles.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 110, 310, 10));

        jCheckBoxRoles.setText("jCheckBoxCustom1");
        jCheckBoxRoles.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jCheckBoxRolesMousePressed(evt);
            }
        });
        PanelRoles.add(jCheckBoxRoles, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 150, -1, -1));

        INICIARSESION.setFont(new java.awt.Font("Roboto Black", 1, 18)); // NOI18N
        INICIARSESION.setForeground(new java.awt.Color(102, 102, 102));
        INICIARSESION.setText("Gestion de Roles");
        PanelRoles.add(INICIARSESION, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 50, -1, -1));

        btnAgregar.setText("Agregar Rol");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });
        PanelRoles.add(btnAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 400, 90, -1));

        btnEditar.setText("Editar Rol");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });
        PanelRoles.add(btnEditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 400, 90, -1));

        BtnEliminar.setText("Eliminar Rol");
        BtnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnEliminarActionPerformed(evt);
            }
        });
        PanelRoles.add(BtnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 400, 90, -1));

        tableRoles.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "N°", "Nombre", "Estado"
            }
        ));
        tableRoles.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableRolesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tableRoles);

        PanelRoles.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 190, -1, 180));

        BtnVaciarDatos.setText("Limpiar");
        BtnVaciarDatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnVaciarDatosActionPerformed(evt);
            }
        });
        PanelRoles.add(BtnVaciarDatos, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 400, 90, -1));

        jPanelMENU.setBackground(new java.awt.Color(255, 255, 255));
        jPanelMENU.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jPanelMENUMouseDragged(evt);
            }
        });
        jPanelMENU.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPanelMENUMousePressed(evt);
            }
        });

        jPanelSalir.setBackground(new java.awt.Color(255, 255, 255));
        jPanelSalir.setPreferredSize(new java.awt.Dimension(40, 40));

        jLabelX.setBackground(new java.awt.Color(255, 255, 255));
        jLabelX.setFont(new java.awt.Font("Roboto Light", 1, 18)); // NOI18N
        jLabelX.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelX.setText("X");
        jLabelX.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelX.setPreferredSize(new java.awt.Dimension(40, 40));
        jLabelX.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelXMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabelXMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabelXMouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanelSalirLayout = new javax.swing.GroupLayout(jPanelSalir);
        jPanelSalir.setLayout(jPanelSalirLayout);
        jPanelSalirLayout.setHorizontalGroup(
            jPanelSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
            .addGroup(jPanelSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanelSalirLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabelX, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanelSalirLayout.setVerticalGroup(
            jPanelSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
            .addGroup(jPanelSalirLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanelSalirLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabelX, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout jPanelMENULayout = new javax.swing.GroupLayout(jPanelMENU);
        jPanelMENU.setLayout(jPanelMENULayout);
        jPanelMENULayout.setHorizontalGroup(
            jPanelMENULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelMENULayout.createSequentialGroup()
                .addContainerGap(614, Short.MAX_VALUE)
                .addComponent(jPanelSalir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanelMENULayout.setVerticalGroup(
            jPanelMENULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanelSalir, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        PanelRoles.add(jPanelMENU, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 660, 30));

        jSeparator4.setForeground(new java.awt.Color(0, 0, 0));
        PanelRoles.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 660, 20));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelRoles, javax.swing.GroupLayout.PREFERRED_SIZE, 655, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelRoles, javax.swing.GroupLayout.DEFAULT_SIZE, 472, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jTextNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextNombreActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        String descripcion = jTextNombre.getText().trim();
        boolean activo = jCheckBoxRoles.isSelected();

        // Ocultar ambos mensajes antes de validar
        jLabelErrorNombre.setVisible(false);
        jLabelErrorRolExistente.setVisible(false);

        // Validar campo vacío
        if (descripcion.isEmpty() || descripcion.equals("Ingrese el nombre del rol")) {
            jLabelErrorNombre.setVisible(true);
            return;
        }

        try {
            rol rolExistente = rolDao.obtenerPorDescripcion(descripcion);

        if (rolExistente != null) {
            if (rolExistente.getEstado() == 2) {
                // Si existe con estado = 2, lo reactivamos
                rolExistente.setEstado(1);
                rolDao.editar(rolExistente); // Actualiza el estado
                JOptionPane.showMessageDialog(this,
                        "Rol registrado exitosamente!",
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
                cargarRolesDesdeBD();
                return;
            } else {
                // Si ya existe activo o inactivo (estado 0 o 1), mostramos error
                jLabelErrorRolExistente.setVisible(true);
                return;
            }
        }
            // Si todo está bien, proceder
            rol nuevo = new rol();
            nuevo.setDescripcion(descripcion);
            nuevo.setEstado(activo ? 1 : 0);

            if (rolDao.agregar(nuevo)) {
                JOptionPane.showMessageDialog(this,
                        "Rol registrado exitosamente!",
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
                cargarRolesDesdeBD();
            } else {
                JOptionPane.showMessageDialog(this,
                        "No se pudo registrar el rol.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Error de base de datos: " + e.getMessage(),
                    "Error técnico", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
    int filaSeleccionada = tableRoles.getSelectedRow();

    jLabelErrorNombre.setVisible(false);
    jLabelErrorRolExistente.setVisible(false);

    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Seleccione un rol para editar",
                "Advertencia", JOptionPane.WARNING_MESSAGE);
        return;
    }

    String nuevaDescripcion = jTextNombre.getText().trim();
    int nuevoEstado = jCheckBoxRoles.isSelected() ? 1 : 0;

    if (nuevaDescripcion.isEmpty() || nuevaDescripcion.equals("Ingrese el nombre del rol")) {
        jLabelErrorNombre.setVisible(true);
        return;
    }

    // Verificar si no hubo cambios
    if (rolOriginalSeleccionado != null &&
            rolOriginalSeleccionado.getDescripcion().equalsIgnoreCase(nuevaDescripcion) &&
            rolOriginalSeleccionado.getEstado() == nuevoEstado) {
        JOptionPane.showMessageDialog(this,
                "No se ha realizado ningún cambio.",
                "Edición no válida", JOptionPane.WARNING_MESSAGE);
        return;
    }

    try {
        // Verificar si existe otro rol con la misma descripción
        rol rolExistente = rolDao.obtenerPorDescripcionExcluyendoId(nuevaDescripcion, idRolSeleccionado);
        
        if (rolExistente != null) {
            // Si existe y está activo/inactivo (0 o 1)
            if (rolExistente.getEstado() == 0 || rolExistente.getEstado() == 1) {
                jLabelErrorRolExistente.setVisible(true);
                return;
            }
            // Si existe y está eliminado (2), lo eliminamos permanentemente
            else if (rolExistente.getEstado() == 2) {
                rolDao.eliminarPermanentemente(rolExistente.getIdRol());
            }
        }

        // Actualizar el rol seleccionado
        rol rolEditado = new rol(idRolSeleccionado, nuevaDescripcion, nuevoEstado);
        boolean actualizado = rolDao.editar(rolEditado);

        if (actualizado) {
            JOptionPane.showMessageDialog(this, "Rol actualizado correctamente");
            cargarRolesDesdeBD();
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo actualizar el rol");
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
                "Error de base de datos: " + e.getMessage(),
                "Error técnico", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }


    }//GEN-LAST:event_btnEditarActionPerformed

    private void BtnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnEliminarActionPerformed
        int filaSeleccionada = tableRoles.getSelectedRow();

        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un rol para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Usamos convertRowIndexToModel porque tienes auto-sorting activado
        int modeloFila = tableRoles.convertRowIndexToModel(filaSeleccionada);

        int idRol = Integer.parseInt(modelo.getValueAt(modeloFila, 3).toString());

        int confirm = JOptionPane.showConfirmDialog(this, "¿Está seguro de eliminar este rol?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                rolDao.eliminar(idRol); // Aquí haces el update a estado = 2
                cargarRolesDesdeBD();
                JOptionPane.showMessageDialog(this, "Rol eliminado correctamente.");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error al eliminar rol: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }


    }//GEN-LAST:event_BtnEliminarActionPerformed

    private void tableRolesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableRolesMouseClicked

        jLabelErrorNombre.setVisible(false); // Ocultar mensaje al iniciar
        jLabelErrorRolExistente.setVisible(false);
        int fila = tableRoles.getSelectedRow();
        if (fila >= 0) {
            // Obtener datos de las columnas correctas
            String descripcion = (String) tableRoles.getValueAt(fila, 1); // Columna 1: Nombre
            String estadoStr = (String) tableRoles.getValueAt(fila, 2);   // Columna 2: Estado
            int id = (int) tableRoles.getValueAt(fila, 3);               // Columna 3: ID real

            // Mostrar en los campos
            jTextNombre.setText(descripcion);
            jTextNombre.setForeground(Color.BLACK);  // Poner texto en negro
            jTextNombre.setEnabled(true);
            jCheckBoxRoles.setSelected("Activo".equalsIgnoreCase(estadoStr));

            // Guardar el ID real seleccionado
            idRolSeleccionado = id;

            // Guardar el rol original para comparación
            rolOriginalSeleccionado = new rol(
                    id,
                    descripcion,
                    "Activo".equalsIgnoreCase(estadoStr) ? 1 : 0
            );

            // Cambiar estado de los botones
            btnAgregar.setEnabled(false);
            btnEditar.setEnabled(true);
        }
    }//GEN-LAST:event_tableRolesMouseClicked

    private void BtnVaciarDatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnVaciarDatosActionPerformed
// 1. Limpiar campos
        jTextNombre.setText("Ingrese el nombre del rol");
        jTextNombre.setForeground(Color.GRAY);
        jTextNombre.setEnabled(true); // Asegurar que sea editable

        jCheckBoxRoles.setSelected(false);

        // 2. Ocultar errores
        jLabelErrorNombre.setVisible(false);
        jLabelErrorRolExistente.setVisible(false);

        // 3. Deseleccionar fila de la tabla
        tableRoles.clearSelection();

        // 4. Habilitar el botón Guardar
        btnAgregar.setEnabled(true);

        // 5. Resetear variables de selección
        idRolSeleccionado = -1;
        rolOriginalSeleccionado = null;

    }//GEN-LAST:event_BtnVaciarDatosActionPerformed

    private void jTextNombreMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextNombreMousePressed
        if (jTextNombre.getText().equals("Ingrese el nombre del rol")) {          
            jTextNombre.setText("");
            jTextNombre.setForeground(Color.black);
               
        }
    }//GEN-LAST:event_jTextNombreMousePressed

    private void jCheckBoxRolesMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jCheckBoxRolesMousePressed
        if (jTextNombre.getText().isEmpty()) {
        jTextNombre.setText("Ingrese el nombre del rol");
        jTextNombre.setForeground(Color.GRAY);
    }
    }//GEN-LAST:event_jCheckBoxRolesMousePressed

    private void jLabelXMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelXMouseClicked
        Window window = SwingUtilities.getWindowAncestor(this);
        if (window != null) {
            window.dispose(); // ✅ esto cierra solo el JFrame contenedor
            
        }
    }//GEN-LAST:event_jLabelXMouseClicked

    private void jLabelXMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelXMouseEntered
        jPanelSalir.setBackground(Color.red);
        jLabelX.setForeground(Color.white);
    }//GEN-LAST:event_jLabelXMouseEntered

    private void jLabelXMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelXMouseExited
        jPanelSalir.setBackground(Color.white);
        jLabelX.setForeground(Color.black);
    }//GEN-LAST:event_jLabelXMouseExited

    private void jPanelMENUMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanelMENUMouseDragged
        Window window = SwingUtilities.getWindowAncestor(this); // obtener JFrame contenedor
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        window.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_jPanelMENUMouseDragged

    private void jPanelMENUMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanelMENUMousePressed
        xMouse= evt.getX();
        yMouse= evt.getY();
    }//GEN-LAST:event_jPanelMENUMousePressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.raven.swing.Button BtnEliminar;
    private com.raven.swing.Button BtnVaciarDatos;
    private javax.swing.JLabel INICIARSESION;
    private javax.swing.JPanel PanelRoles;
    private com.raven.swing.Button btnAgregar;
    private com.raven.swing.Button btnEditar;
    private javax.swing.ButtonGroup buttonGroup1;
    private com.raven.swing.JCheckBoxCustom jCheckBoxRoles;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabelErrorNombre;
    private javax.swing.JLabel jLabelErrorRolExistente;
    private javax.swing.JLabel jLabelX;
    private javax.swing.JPanel jPanelMENU;
    private javax.swing.JPanel jPanelSalir;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JTextField jTextNombre;
    private javax.swing.JTable tableRoles;
    // End of variables declaration//GEN-END:variables
}
