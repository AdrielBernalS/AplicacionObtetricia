
package Controlador;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    public static Connection conectar() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    Connection con;

    public Connection getConnection() {
        try {
            String myBD = "jdbc:sqlserver://localhost:1433;"
               +"database=BD_OBST;"
                +"user=adriel_bernal123;"
                +"password=laglesbs123;"
                +"loginTimeout=30;"
                + "TrustServerCertificate=True;";

            con = DriverManager.getConnection(myBD);
            return con;
        } catch (SQLException e) {
            System.out.println(e.toString());
            return null;
        }
    }
}