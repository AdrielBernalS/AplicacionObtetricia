
package Controlador;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class LoginDAO {
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    Conexion cn = new Conexion();
    
    private static login usuarioLogueado;  // Esta variable debe ser actualizada cuando el usuario inicie sesión
    
    public login log(String usuario, String password, String nombre, String apellido) { 
        login l = new login();
        String sql = "SELECT * FROM usuario " +
             "WHERE usuario COLLATE Latin1_General_CS_AS = ? " +
             "AND password COLLATE Latin1_General_CS_AS = ?";
        
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, usuario);
            ps.setString(2, password);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                l.setId(rs.getInt("idUsuario"));
                l.setNombre(rs.getString("nombre"));
                l.setApellido(rs.getString("apellido"));
                l.setDNI(rs.getInt("DNI"));
                l.setCelular(rs.getInt("celular"));
                l.setIdRol(rs.getInt("idRol"));
                l.setUsuario(rs.getString("usuario"));
                l.setPassword(rs.getString("password"));
                l.setEstado(rs.getInt("estado"));
                l.setFoto(rs.getBytes("foto"));

                // Asignar el usuario a la variable estática
                usuarioLogueado = l;
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        } finally {
            // Asegurarse de cerrar recursos
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.toString());
            }
        }
        return l;  // Retorna el objeto, pero ahora ya está asignado a la variable estática
    }

    public static login obtenerUsuarioLogueado() {
        return usuarioLogueado;  // Retorna el usuario actualmente logueado
    }

    public boolean existeUsuario(String usuario) {
        String sql = "SELECT usuario FROM usuario WHERE usuario COLLATE Latin1_General_CS_AS= ?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, usuario);
            rs = ps.executeQuery();
            return rs.next(); // Retorna true si encuentra el usuario
        } catch (SQLException e) {
            System.out.println(e.toString());
            return false;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.toString());
            }
        }
    }

    public boolean validarNombreYDni(String nombre, String apellido, String dni) {

        String sql = "SELECT COUNT(*) FROM usuario WHERE nombre = ? AND apellido = ? AND DNI = ?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, nombre);
            ps.setString(2, apellido);
            ps.setInt(3, Integer.parseInt(dni)); // Convertir String a int (DNI es INT en tu BD)
            rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0; // True si existe el usuario con ese DNI
            }
        } catch (SQLException e) {
            System.out.println("Error al validar usuario y DNI: " + e.toString());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println("Error al cerrar recursos: " + ex.toString());
            }
        }
        return false;
    }

    public boolean actualizarContraseña(String dni, String nuevaContraseña) {
        String sql = "UPDATE usuario SET password = ? WHERE dni = ?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, nuevaContraseña); // En producción, usa BCrypt o SHA-256
            ps.setString(2, dni);

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0; // True si se actualizó al menos una fila
        } catch (SQLException e) {
            System.out.println("Error al actualizar contraseña: " + e.toString());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                System.out.println("Error al cerrar recursos: " + ex.toString());
            }
        }
        return false;
    }

    public boolean actualizarFoto(int idUsuario, byte[] foto) {
        String sql = "UPDATE usuario SET foto = ? WHERE idUsuario = ?";
        try (Connection con = cn.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            if (foto == null || foto.length == 0) {
                ps.setNull(1, java.sql.Types.BLOB);
            } else {
                ps.setBytes(1, foto);
            }
            ps.setInt(2, idUsuario);

            int filas = ps.executeUpdate();
            System.out.println("Filas actualizadas: " + filas);
            if (filas > 0) {
                // Actualizar el usuario en memoria
                if (usuarioLogueado != null && usuarioLogueado.getId() == idUsuario) {
                    usuarioLogueado.setFoto(foto);
                }
                return true;
            }
            return false;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Método para actualizar celular por DNI (ya lo tienes, pero asegurémonos que esté correcto)
    public boolean actualizarCelular(int dni, int nuevoCelular) {
        String sql = "UPDATE usuario SET celular = ? WHERE DNI = ?";

        try (Connection con = cn.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, nuevoCelular);
            ps.setInt(2, dni);  // DNI como int

            int filasAfectadas = ps.executeUpdate();

            if (filasAfectadas > 0) {
                synchronized (LoginDAO.class) {
                    if (usuarioLogueado != null && usuarioLogueado.getDNI() == dni) {
                        usuarioLogueado.setCelular(nuevoCelular);
                        System.out.println("Memoria actualizada: " + nuevoCelular);
                    }
                }
                return true;
            }
            return false;

        } catch (SQLException e) {
            System.err.println("Error al actualizar celular: " + e.getMessage());
            return false;
        }
    }

// Método para obtener usuario por DNI (corregido para usar int)
    public login obtenerUsuarioPorDNI(int dni) {
        String sql = "SELECT * FROM usuario WHERE DNI = ?";
        login usuario = null;

        try (Connection con = cn.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, dni);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                usuario = new login();
                usuario.setId(rs.getInt("idUsuario"));
                usuario.setNombre(rs.getString("nombre"));
                usuario.setApellido(rs.getString("apellido"));
                usuario.setDNI(rs.getInt("DNI"));
                usuario.setCelular(rs.getInt("celular"));
                usuario.setUsuario(rs.getString("usuario"));
                // Agrega otros campos según necesites
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener usuario por DNI: " + e.getMessage());
        }

        return usuario;
    }

// Método para verificar contraseña (usando DNI como int)
    public boolean verificarContraseñaActual(int dni, String contraseñaActual) {
        String sql = "SELECT idUsuario FROM usuario WHERE DNI = ? AND password = ?";

        try (Connection con = cn.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, dni);
            ps.setString(2, contraseñaActual);
            ResultSet rs = ps.executeQuery();

            return rs.next();

        } catch (SQLException e) {
            System.err.println("Error al verificar contraseña: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarContraseñaPORMENU(int dni, String nuevaContraseña) {
        String sql = "UPDATE usuario SET password = ? WHERE DNI = ?";

        try (Connection con = cn.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, nuevaContraseña);
            ps.setInt(2, dni);

            int filasAfectadas = ps.executeUpdate();

            // Actualizar el objeto en memoria si es el usuario logueado
            if (filasAfectadas > 0 && usuarioLogueado != null
                    && usuarioLogueado.getDNI() == dni) {
                usuarioLogueado.setPassword(nuevaContraseña);
            }

            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al actualizar contraseña: " + e.getMessage());
            return false;
        }
    }

    public List<login> listarUsuarios() {
        List<login> lista = new ArrayList<>();
        String sql = "SELECT * FROM usuario";

        try (Connection con = cn.getConnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                login l = new login();
                l.setId(rs.getInt("idUsuario"));
                l.setNombre(rs.getString("nombre"));
                l.setApellido(rs.getString("apellido"));
                l.setDNI(rs.getInt("DNI"));
                l.setCelular(rs.getInt("celular"));
                l.setUsuario(rs.getString("usuario"));
                l.setPassword(rs.getString("password"));
                l.setEstado(rs.getInt("estado"));
                l.setFoto(rs.getBytes("foto"));
                l.setIdRol(rs.getInt("idRol"));
                lista.add(l);
            }

        } catch (SQLException e) {
            System.out.println("Error al listar usuarios: " + e.toString());
        }
        return lista;
    }

    public boolean registrarUsuario(login u) {
        String sql = "INSERT INTO usuario(nombre, apellido, DNI, celular, usuario, password, estado, idRol) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = cn.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, u.getNombre());
            ps.setString(2, u.getApellido());
            ps.setInt(3, u.getDNI());
            ps.setInt(4, u.getCelular());
            ps.setString(5, u.getUsuario());
            ps.setString(6, u.getPassword());
            ps.setInt(7, u.getEstado());
            ps.setInt(8, u.getIdRol());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error al registrar usuario: " + e.toString());
            return false;
        }
    }

    
}
