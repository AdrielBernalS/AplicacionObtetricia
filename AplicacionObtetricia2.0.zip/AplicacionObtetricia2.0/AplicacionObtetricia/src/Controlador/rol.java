
package Controlador;


public class rol {
    private int idRol;
    private String descripcion;
    private int estado;

    public rol(int idRol, String descripcion, int estado) {
        this.idRol = idRol;
        this.descripcion = descripcion;
        this.estado = estado;
    }

    public rol() {
    }

    
    public int getIdRol() {
        return idRol;
    }

    public void setIdRol(int idRol) {
        this.idRol = idRol;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }
    
    
    @Override
    public String toString() {
        return descripcion; // para que en el JComboBox se muestre solo el nombre
    }
}
