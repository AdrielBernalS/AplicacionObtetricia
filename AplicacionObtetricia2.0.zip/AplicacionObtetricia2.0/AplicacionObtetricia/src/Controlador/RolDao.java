
package Controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.SQLException;


public class RolDao {
    
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    Conexion cn = new Conexion();

    public List<rol> listarRoles() {

        List<rol> lista = new ArrayList<>();
        String sql = "SELECT * FROM rol WHERE estado IN (0, 1)";

        try (Connection con = cn.getConnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) { // Manejo automático de recursos
            
            while (rs.next()) {
                rol Rl = new rol(
                        rs.getInt("idRol"),
                        rs.getString("descripcion"),
                        rs.getInt("estado")
                );

                lista.add(Rl);
            }

        } catch (Exception e) {
            System.err.println("Error al listar roles: " + e.getMessage());
            e.printStackTrace();
        }

        return lista;
    }

    public boolean agregar(rol rol) {
        String sql = "INSERT INTO rol (descripcion, estado) VALUES (?, ?)";
        try (Connection con = cn.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, rol.getDescripcion());
            ps.setInt(2, rol.getEstado());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error al agregar rol: " + e.getMessage());
            return false;
        }
    }

    public boolean editar(rol rol) {
        String sql = "UPDATE rol SET descripcion = ?, estado = ? WHERE idRol = ?";
        try (Connection con = cn.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, rol.getDescripcion());
            ps.setInt(2, rol.getEstado());
            ps.setInt(3, rol.getIdRol());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error al editar rol: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int idRol) {
        String sql = "UPDATE rol SET estado = 2 WHERE idRol = ?";
        try (Connection con = cn.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idRol);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error al eliminar rol: " + e.getMessage());
            return false;
        }
    }

    public boolean existeRol(String descripcion) throws SQLException {
        String sql = "SELECT COUNT(*) FROM rol WHERE descripcion = ?";
        try (Connection con = cn.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, descripcion.trim()); // Usa trim() para eliminar espacios
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    public rol obtenerPorDescripcion(String descripcion) throws SQLException {
        String sql = "SELECT * FROM rol WHERE descripcion = ?";
        try (Connection con = cn.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, descripcion);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new rol(
                            rs.getInt("idRol"),
                            rs.getString("descripcion"),
                            rs.getInt("estado")
                    );
                }
            }
        }
        return null;
    }

    public rol obtenerPorDescripcionExcluyendoId(String descripcion, int idExcluir) throws SQLException {
        String sql = "SELECT * FROM rol WHERE descripcion = ? AND idRol != ?";
        try (Connection con = cn.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, descripcion);
            ps.setInt(2, idExcluir);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new rol(
                            rs.getInt("idRol"),
                            rs.getString("descripcion"),
                            rs.getInt("estado")
                    );
                }
            }
        }
        return null;
    }

    public boolean eliminarPermanentemente(int idRol) throws SQLException {
        String sql = "DELETE FROM rol WHERE idRol = ?";
        try (Connection con = cn.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idRol);
            return ps.executeUpdate() > 0;
        }
    }
    
    public String obtenerNombreRolPorId(int idRol) {
        String sql = "SELECT descripcion FROM rol WHERE idRol = ?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, idRol);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("descripcion");
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener nombre del rol: " + e.toString());
        }
        return "Desconocido";
    }
}
