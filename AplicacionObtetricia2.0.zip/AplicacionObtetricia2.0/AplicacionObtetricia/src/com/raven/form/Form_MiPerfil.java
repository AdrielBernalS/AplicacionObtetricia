
package com.raven.form;

import java.awt.Color;
import javax.swing.JPasswordField;
import java.awt.GridLayout;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import Controlador.LoginDAO;
import Controlador.login;
import com.raven.component.Profile;
import com.raven.main.Main.SistemaPerfil;
import java.awt.BasicStroke;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Stroke;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.filechooser.FileNameExtensionFilter;


public class Form_MiPerfil extends javax.swing.JPanel {

    JLabel lblFotoPerfil;
    JLabel lblNombreUsuario;
    JButton btnCambiarFoto;  // declaración en la clase
    private JPanel panelDatos;
    private JLabel lblValorCelular;
    private JPanel panelCelular; // También necesitamos esta referencia
    private Profile perfilUsuario;
    private JLabel lblRol;



    public Form_MiPerfil() {
        initComponents();
        perfilUsuario = new Profile();
        lblFotoPerfil = new JLabel();
        lblFotoPerfil.setPreferredSize(new Dimension(250, 250));
        lblFotoPerfil.setSize(250, 250);
        jPanel1.add(lblFotoPerfil, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 50, 250, 250));
        
        //LINEA SEPARADORA
        JSeparator lineaVertical = new JSeparator(SwingConstants.VERTICAL);
        lineaVertical.setPreferredSize(new Dimension(1, 500)); // grosor 1 px, alto similar al panelDatos
        lineaVertical.setBackground(new Color(173, 216, 230)); // celeste
        lineaVertical.setOpaque(true);
        float[] dashPattern = {5f, 5f}; // más fino aún
        Stroke dashed = new BasicStroke(1f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_MITER, 10f, dashPattern, 0);

        // Crear un JLabel para mostrar el nombre debajo de la imagen
        lblNombreUsuario = new JLabel();
        lblNombreUsuario.setFont(new Font("Arial", Font.BOLD, 18));
        lblNombreUsuario.setForeground(Color.BLACK); // Puedes ajustar el color
        lblNombreUsuario.setHorizontalAlignment(SwingConstants.CENTER);

        // Posición debajo de la imagen
        jPanel1.add(lblNombreUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 320, 250, 30));

        // Obtener el nombre del usuario desde LoginDAO
        login usuario = LoginDAO.obtenerUsuarioLogueado();
        if (usuario != null) {
            String nombreCompleto = usuario.getNombre() + " " + usuario.getApellido();
            lblNombreUsuario.setText(nombreCompleto);
            mostrarImagenCircularDesdeBytes(lblFotoPerfil, usuario.getFoto());

        } else {
            lblNombreUsuario.setText("Usuario desconocido");
            mostrarImagenCircularDesdeArchivo(lblFotoPerfil, "/com/raven/icon/profile.jpg");


        }

        jPanel1.setOpaque(false);
        jPanel1.setBackground(new Color(0, 0, 0, 0));

        // Inicializar el botón si no está en initComponents
        btnCambiarFoto = new JButton("Cambiar Foto");
        btnCambiarFoto.setBounds(650, 320, 250, 35); // ejemplo, si usas AbsoluteLayout
        jPanel1.add(btnCambiarFoto, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 375, 350, 50));
        configurarBotonCambiarFoto(); // Aplicar los estilos
        btnCambiarFoto.addActionListener(e -> seleccionarYActualizarFoto());
        jPanel1.revalidate();
        jPanel1.repaint();

        //EFECTO AL HACER CLICK AL BOTON
        btnCambiarFoto.addChangeListener(e -> {
            if (btnCambiarFoto.getModel().isPressed()) {
                btnCambiarFoto.setBackground(new Color(0, 82, 164)); // Color más oscuro al presionar
            } else if (btnCambiarFoto.getModel().isRollover()) {
                btnCambiarFoto.setBackground(new Color(0, 122, 255)); // Color hover
            } else {
                btnCambiarFoto.setBackground(new Color(0, 102, 204)); // Color normal
            }
        });

        // Añade un icono de cámara al botón
        ImageIcon iconoCamara = new ImageIcon(getClass().getResource("/com/raven/icon/CAMARA.png"));
        // Redimensiona el icono si es necesario
        Image img = iconoCamara.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
        btnCambiarFoto.setIcon(new ImageIcon(img));
        btnCambiarFoto.setHorizontalTextPosition(SwingConstants.LEFT);
        btnCambiarFoto.setIconTextGap(10);

        // En el constructor de Form_MiPerfil, después de tu código existente:
        // Panel contenedor para los datos
        JPanel panelDatos = new JPanel();
        panelDatos.setLayout(new BoxLayout(panelDatos, BoxLayout.Y_AXIS));
        panelDatos.setOpaque(false);
        panelDatos.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 20)); // Márgenes
        jPanel1.add(panelDatos, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, 400, 500));
        jPanel1.add(lineaVertical, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 30, 3, 500));

        // Etiqueta de bienvenida
        JLabel lblBienvenida = new JLabel("¡Bienvenida!");
        lblBienvenida.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblBienvenida.setForeground(new Color(0, 102, 204)); // Azul
        lblBienvenida.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelDatos.add(lblBienvenida);
        panelDatos.add(Box.createRigidArea(new Dimension(0, 20))); // Espacio

        // Mostrar datos del usuario
        mostrarDatosUsuario(panelDatos);     
        
        
        //ROL DE USUARIO DEBAJO DEL BOTON DE CAMBIAR FOTO
        lblRol = new JLabel();
        lblRol.setFont(new Font("Arial", Font.PLAIN, 16));
        lblRol.setHorizontalAlignment(SwingConstants.CENTER);
        jPanel1.add(lblRol, new org.netbeans.lib.awtextra.AbsoluteConstraints(650,470, 250, 20));

        // Obtener y mostrar el rol
        if (usuario != null) {
            String textoRol = "<html><b>Rol:</b> ";
            if (usuario.getIdRol() == 1) {
                textoRol += "Administrador";
            } else if (usuario.getIdRol() == 2) {
                textoRol += "Obstetra";
            } else {
                textoRol += "Rol desconocido";
            }
            textoRol += "</html>"; // Cerramos el HTML
            lblRol.setText(textoRol);
        } else {
            lblRol.setText("Rol: No definido");
        }

        lblRol.setForeground(new Color(80, 80, 80));

        ImageIcon iconoRol = new ImageIcon(getClass().getResource("/com/raven/icon/Clientes.png"));
        Image imgRol = iconoRol.getImage().getScaledInstance(16, 16, Image.SCALE_SMOOTH);
        lblRol.setIcon(new ImageIcon(imgRol));
        lblRol.setIconTextGap(5);
    }

    private void mostrarImagenCircularDesdeBytes(JLabel label, byte[] datosImagen) {
        BufferedImage imagenOriginal = null;

        try {
            if (datosImagen != null) {
                imagenOriginal = ImageIO.read(new java.io.ByteArrayInputStream(datosImagen));
            }
        
        // Si imagenOriginal es null (bytes corruptos o mala ruta), intenta cargar la imagen por defecto
        if (imagenOriginal == null) {
            imagenOriginal = ImageIO.read(getClass().getResource("/com/raven/icon/profile.jpg"));
        }

        // Si sigue siendo null, no hay imagen válida, limpiar icono y salir
        if (imagenOriginal == null) {
            label.setIcon(null);
            System.err.println("No se pudo cargar ninguna imagen válida.");
            return;
        }

        int tamaño = Math.min(label.getWidth(), label.getHeight());
        if (tamaño <= 0) {
            tamaño = 250;  // El tamaño fijo que definiste para lblFotoPerfil
        }

        Image imagenRedimensionada = imagenOriginal.getScaledInstance(tamaño, tamaño, Image.SCALE_SMOOTH);
        BufferedImage imagenCircular = new BufferedImage(tamaño, tamaño, BufferedImage.TYPE_INT_ARGB);

        Graphics2D g2 = imagenCircular.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setClip(new Ellipse2D.Float(0, 0, tamaño, tamaño));
        g2.drawImage(imagenRedimensionada, 0, 0, null);
        g2.dispose();

        label.setIcon(new ImageIcon(imagenCircular));
    } catch (IOException e) {
        e.printStackTrace();
        label.setIcon(null);
    }
}


    private void mostrarImagenCircularDesdeArchivo(JLabel label, String rutaArchivo) {
        try {
            BufferedImage imagenOriginal = ImageIO.read(getClass().getResourceAsStream(rutaArchivo));

            int tamaño = Math.min(label.getWidth(), label.getHeight());

            Image imagenRedimensionada = imagenOriginal.getScaledInstance(tamaño, tamaño, Image.SCALE_SMOOTH);
            BufferedImage imagenCircular = new BufferedImage(tamaño, tamaño, BufferedImage.TYPE_INT_ARGB);

            Graphics2D g2 = imagenCircular.createGraphics();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setClip(new Ellipse2D.Float(0, 0, tamaño, tamaño));
            g2.drawImage(imagenRedimensionada, 0, 0, null);
            g2.dispose();

            label.setIcon(new ImageIcon(imagenCircular));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void seleccionarYActualizarFoto() {
        JFileChooser chooser = new JFileChooser();
        FileNameExtensionFilter filtro = new FileNameExtensionFilter("Imágenes PNG y JPG", "png", "jpg", "jpeg");
        chooser.setFileFilter(filtro);

        int resultado = chooser.showOpenDialog(this);
        if (resultado == JFileChooser.APPROVE_OPTION) {
            File archivoSeleccionado = chooser.getSelectedFile();

            try {
                // Verificar tamaño del archivo (ejemplo: máximo 2MB)
                long fileSize = archivoSeleccionado.length();
                if (fileSize > 2 * 1024 * 1024) {
                    JOptionPane.showMessageDialog(this, "La imagen no debe exceder los 2MB", "Archivo muy grande", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                login usuario = LoginDAO.obtenerUsuarioLogueado();
                if (usuario == null) {
                    JOptionPane.showMessageDialog(this, "No hay usuario logueado", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                byte[] bytesFoto = convertirImagenABytes(archivoSeleccionado);
                if (bytesFoto == null || bytesFoto.length == 0) {
                    JOptionPane.showMessageDialog(this, "Error al convertir la imagen", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                if(usuario.getFoto() != null){
                    SistemaPerfil.setFotoPerfil(usuario.getFoto());
                }

                boolean exito = new LoginDAO().actualizarFoto(usuario.getId(), bytesFoto);

                if (exito) {
                    SistemaPerfil.setFotoPerfil(bytesFoto);
                    // Actualizar la interfaz directamente con la nueva imagen
                    mostrarImagenCircularDesdeBytes(lblFotoPerfil, bytesFoto);                 
                    JOptionPane.showMessageDialog(this, "Foto actualizada correctamente");
                } else {
                    JOptionPane.showMessageDialog(this, "Error al actualizar la foto en la base de datos");
                }
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error al procesar la imagen: " + ex.getMessage());
            }
        }
    }

    private byte[] convertirImagenABytes(File archivo) throws IOException {
        try (FileInputStream fis = new FileInputStream(archivo); ByteArrayOutputStream baos = new ByteArrayOutputStream()) {

            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                baos.write(buffer, 0, bytesRead);
            }
            return baos.toByteArray();
        }
    }

    //DISEÑO BOTON CAMBIARFOTO
    // Añade este método para estilizar el botón
    private void configurarBotonCambiarFoto() {
        // Estilo básico
        btnCambiarFoto.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnCambiarFoto.setForeground(Color.WHITE);
        btnCambiarFoto.setBackground(new Color(0, 102, 204)); // Azul moderno
        btnCambiarFoto.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));

        // Efecto hover
        btnCambiarFoto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnCambiarFoto.setBackground(new Color(0, 122, 255)); // Azul más claro al pasar mouse
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnCambiarFoto.setBackground(new Color(0, 102, 204)); // Vuelve al color original
            }
        });

        // Bordes redondeados
        btnCambiarFoto.setBorder(new RoundedBorder(15)); // 15 es el radio de curvatura
    }

// Clase para bordes redondeados (añádela como clase interna)
    private class RoundedBorder implements Border {

        private int radius;

        public RoundedBorder(int radius) {
            this.radius = radius;
        }

        public Insets getBorderInsets(Component c) {
            return new Insets(this.radius + 1, this.radius + 1, this.radius + 1, this.radius + 1);
        }

        public boolean isBorderOpaque() {
            return true;
        }

        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            g.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
        }
    }

    // Dentro de tu clase Form_MiPerfil (después de los métodos existentes):
    private void mostrarDatosUsuario(JPanel panelPadre) {
        login usuario = LoginDAO.obtenerUsuarioLogueado();
        lblValorCelular = new JLabel(usuario.getCelular() != 0 ? String.valueOf(usuario.getCelular()) : "No registrado");

        if (usuario == null) {
            panelPadre.add(new JLabel("No se pudo cargar la información del usuario"));
            panelDatos.revalidate();
            panelDatos.repaint();
            return;
        }

        // Fuentes para los textos
        Font fontTitulo = new Font("Segoe UI", Font.BOLD, 16);
        Font fontDato = new Font("Segoe UI", Font.PLAIN, 16);
        Font fontBoton = new Font("Segoe UI", Font.PLAIN, 14);

        // Espaciado entre componentes
        Dimension espacio = new Dimension(0, 25);

        // Datos no editables (solo visualización)
        panelPadre.add(Box.createRigidArea(espacio));
        agregarCampoNoEditable(panelPadre, "Nombre:", usuario.getNombre(), fontTitulo, fontDato);
        panelPadre.add(Box.createRigidArea(espacio));

        agregarCampoNoEditable(panelPadre, "Apellido:", usuario.getApellido(), fontTitulo, fontDato);
        panelPadre.add(Box.createRigidArea(espacio));

        agregarCampoNoEditable(panelPadre, "DNI:", String.valueOf(usuario.getDNI()), fontTitulo, fontDato);
        panelPadre.add(Box.createRigidArea(espacio));

        agregarCampoNoEditable(panelPadre, "Usuario:", usuario.getUsuario(), fontTitulo, fontDato);
        panelPadre.add(Box.createRigidArea(espacio));

        // Campo editable: Celular
        panelCelular = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        panelCelular.setOpaque(false);

        JLabel lblCelular = new JLabel("Celular:");
        lblCelular.setFont(fontTitulo);
        lblCelular.setPreferredSize(new Dimension(100, 20));
        lblValorCelular = new JLabel(usuario.getCelular() != 0 ? String.valueOf(usuario.getCelular()) : "No registrado");
        lblValorCelular.setFont(fontDato);

        JButton btnEditarCelular = new JButton("Editar");
        btnEditarCelular.setFont(fontBoton);
        btnEditarCelular.setBackground(new Color(240, 240, 240));
        btnEditarCelular.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        btnEditarCelular.addActionListener(e -> editarCelular());

        panelCelular.add(lblCelular);
        panelCelular.add(lblValorCelular);
        panelCelular.add(btnEditarCelular);
        panelPadre.add(panelCelular);
        panelPadre.add(Box.createRigidArea(espacio));

        // Campo editable: Contraseña
        JPanel panelPassword = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        panelPassword.setOpaque(false);

        JLabel lblPassword = new JLabel("Contraseña:");
        lblPassword.setFont(fontTitulo);
        lblPassword.setPreferredSize(new Dimension(100, 20));

        JLabel lblValorPassword = new JLabel("••••••••");
        lblValorPassword.setFont(fontDato);

        JButton btnCambiarPassword = new JButton("Cambiar");
        btnCambiarPassword.setFont(fontBoton);
        btnCambiarPassword.setBackground(new Color(240, 240, 240));
        btnCambiarPassword.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        btnCambiarPassword.addActionListener(e -> cambiarPassword());

        panelPassword.add(lblPassword);
        panelPassword.add(lblValorPassword);
        panelPassword.add(btnCambiarPassword);
        panelPadre.add(panelPassword);
    }

    private void agregarCampoNoEditable(JPanel panelPadre, String titulo, String valor, Font fontTitulo, Font fontDato) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        panel.setOpaque(false);

        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(fontTitulo);
        lblTitulo.setPreferredSize(new Dimension(100, 20));

        JLabel lblValor = new JLabel(valor);
        lblValor.setFont(fontDato);

        panel.add(lblTitulo);
        panel.add(lblValor);
        panelPadre.add(panel);
    }

    private void editarCelular() {
        login usuario = LoginDAO.obtenerUsuarioLogueado();
        if (usuario == null) {
            JOptionPane.showMessageDialog(this, "No hay usuario logueado", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String nuevoCelularStr = JOptionPane.showInputDialog(
                this,
                "Ingrese su nuevo número de celular:",
                usuario.getCelular() != 0 ? String.valueOf(usuario.getCelular()) : ""
        );

        if (nuevoCelularStr != null && !nuevoCelularStr.trim().isEmpty()) {
            try {
                int nuevoCelular = Integer.parseInt(nuevoCelularStr);
                int dni = usuario.getDNI();

                if (new LoginDAO().actualizarCelular(dni, nuevoCelular)) {

                    usuario.setCelular(nuevoCelular);
                    if (lblValorCelular != null) {
                        lblValorCelular.setText(String.valueOf(nuevoCelular));
                        if (lblValorCelular.getParent() != null) {
                            lblValorCelular.getParent().revalidate(); // Re-calcula el layout
                            lblValorCelular.getParent().repaint();
                        }
                        JOptionPane.showMessageDialog(this, "Celular actualizado correctamente");
                        refrescarPanelDatos();

                    } else {
                        JOptionPane.showMessageDialog(this,
                                "No se pudo actualizar en la base de datos",
                                "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }}
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this,
                        "Por favor ingrese solo números",
                        "Formato inválido",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }
        
    private void cambiarPassword() {
        login usuario = LoginDAO.obtenerUsuarioLogueado();
        if (usuario == null) {
            JOptionPane.showMessageDialog(this, "No hay usuario logueado", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JPanel panel = new JPanel(new GridLayout(3, 2, 5, 5));
        JPasswordField txtActual = new JPasswordField();
        JPasswordField txtNueva = new JPasswordField();
        JPasswordField txtConfirmar = new JPasswordField();

        panel.add(new JLabel("Contraseña actual:"));
        panel.add(txtActual);
        panel.add(new JLabel("Nueva contraseña:"));
        panel.add(txtNueva);
        panel.add(new JLabel("Confirmar contraseña:"));
        panel.add(txtConfirmar);

        int opcion = JOptionPane.showConfirmDialog(
                this, panel, "Cambiar contraseña",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );

        if (opcion == JOptionPane.OK_OPTION) {
            String actual = new String(txtActual.getPassword());
            String nueva = new String(txtNueva.getPassword());
            String confirmar = new String(txtConfirmar.getPassword());
            int dni = usuario.getDNI(); // Obtenemos el DNI como int

            // Validación 1: Contraseña actual correcta
            if (!new LoginDAO().verificarContraseñaActual(dni, actual)) {
                JOptionPane.showMessageDialog(this,
                        "La contraseña actual no es correcta",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Validación 2: Coincidencia de nuevas contraseñas
            if (!nueva.equals(confirmar)) {
                JOptionPane.showMessageDialog(this,
                        "Las nuevas contraseñas no coinciden",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Validación 3: Longitud mínima
            if (nueva.length() < 6) {
                JOptionPane.showMessageDialog(this,
                        "La contraseña debe tener al menos 6 caracteres",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Actualizar contraseña
            if (new LoginDAO().actualizarContraseñaPORMENU(dni, nueva)) {
                JOptionPane.showMessageDialog(this,
                        "Contraseña actualizada correctamente");
            } else {
                JOptionPane.showMessageDialog(this,
                        "Error al actualizar contraseña",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void refrescarPanelDatos() {
        if (panelDatos == null) {
            return;
        }

        login usuario = LoginDAO.obtenerUsuarioLogueado();
        if (usuario == null) {
            return;
        }

        // Buscar y actualizar solo el campo de celular
        actualizarCampoIndividual("Celular:", String.valueOf(usuario.getCelular()));

        // Actualizar otros elementos dinámicos si es necesario
        lblNombreUsuario.setText(usuario.getNombre() + " " + usuario.getApellido());
        if (usuario.getFoto() != null) {
            mostrarImagenCircularDesdeBytes(lblFotoPerfil, usuario.getFoto());
        }
    }

private void actualizarCampoIndividual(String nombreCampo, String nuevoValor) {
    for (Component comp : panelDatos.getComponents()) {
        if (comp instanceof JPanel) {
            JPanel panel = (JPanel) comp;
            for (Component subComp : panel.getComponents()) {
                if (subComp instanceof JLabel && ((JLabel)subComp).getText().equals(nombreCampo)) {
                    // Encontramos el título, ahora buscar el valor a actualizar
                    for (Component valueComp : panel.getComponents()) {
                        if (valueComp instanceof JLabel && !((JLabel)valueComp).getText().equals(nombreCampo)) {
                            ((JLabel)valueComp).setText(nuevoValor);
                            panel.revalidate();
                            panel.repaint();
                            return;
                        }
                    }
                }
            }
        }
    }
}

public class SesionUsuario {
    private static login usuarioActual;

    public static void setUsuario(login usuario) {
        usuarioActual = usuario;
    }

    public static login getUsuario() {
        return usuarioActual;
    }

    public static int getDNI() {
        return usuarioActual != null ? usuarioActual.getDNI() : 0;
    }
}

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();

        setBackground(new java.awt.Color(250, 250, 250));

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(1106, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 692, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
