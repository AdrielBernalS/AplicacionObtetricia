
package com.raven.form;

import Controlador.LoginDAO;
import Controlador.RolDao;
import Controlador.login;
import Controlador.rol;
import Vistas.GestionarRoles;
import java.awt.Color;
import java.util.List;
import java.util.Random;
import javax.swing.JFrame;
import com.raven.swing.TableGradientCell;
import com.formdev.flatlaf.FlatClientProperties;
import javax.swing.table.DefaultTableModel;
import com.formdev.flatlaf.themes.FlatMacDarkLaf;
import com.formdev.flatlaf.FlatLaf;
import com.raven.swing.ScrollBar;
import com.raven.swing.TableHeader;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.Window;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.sql.SQLException;
import javax.imageio.ImageIO;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;

public class Form_GestionUsuario extends javax.swing.JPanel {

    private Integer idUsuarioEditando = null;

    public Form_GestionUsuario() {
        initComponents();

        jPanelUsuarios.setBackground(new java.awt.Color(0, 0, 0, 0));  // Establecer fondo transparente

        jTextNombres.setBackground(new Color(0, 0, 0, 0));  // Fondo transparente
        jTextNombres.setOpaque(false);

        jTextApellidos.setBackground(new Color(0, 0, 0, 0));  // Fondo transparente
        jTextApellidos.setOpaque(false);

        jTextDni.setBackground(new Color(0, 0, 0, 0));  // Fondo transparente
        jTextDni.setOpaque(false);

        jTextTelefono.setBackground(new Color(0, 0, 0, 0));  // Fondo transparente
        jTextTelefono.setOpaque(false);

        jTextUsuario.setBackground(new Color(0, 0, 0, 0));  // Fondo transparente
        jTextUsuario.setOpaque(false);

        jTextContraseña.setBackground(new Color(0, 0, 0, 0));  // Fondo transparente
        jTextContraseña.setOpaque(false);

        comboBox1.setBackground(new Color(0, 0, 0, 0));  // Fondo transparente

        jCheckBoxEstado.setText("Inactivo");
        jCheckBoxEstado.setFont(new Font("Roboto", Font.BOLD, 14));

        jCheckBoxEstado.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (jCheckBoxEstado.isSelected()) {
                    jCheckBoxEstado.setText("Activo");
                } else {
                    jCheckBoxEstado.setText("Inactivo");
                }
            }
        });
        
        // 1. Configuración básica de FlatLaf para la tabla
        UIManager.put("TableHeader.height", 28);
        UIManager.put("Table.rowHeight", 30);
        UIManager.put("Table.cellFocusColor", null);

        // 2. Configurar el renderizador del encabezado
        tableUsuarios.getTableHeader().setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                return new TableHeader(value != null ? value.toString() : "");
            }
        });

        // 3. Configuración específica de FlatLaf para la tabla
        tableUsuarios.putClientProperty(FlatClientProperties.STYLE, ""
                + "border:0,0,0,0,shade(@background,5%),,0;"
                + "selectionBackground:rgb(57,105,138);"
                + "selectionForeground:white;"
                + "cellFocusColor:null;");

        // 4. Configuración del scroll pane
        jScrollPane1.putClientProperty(FlatClientProperties.STYLE, ""
                + "border:3,0,3,0,$Table.background,10,10");
        jScrollPane1.getVerticalScrollBar().putClientProperty(FlatClientProperties.STYLE, ""
                + "hoverTrackColor:null");

        // 5. Configuración del panel contenedor
        jPanelUsuarios.putClientProperty(FlatClientProperties.STYLE, ""
                + "border:1,1,1,1,$TableHeader.bottomSeparatorColor,,10;"
                + "unifiedBackground:false;");

        // 6. Configuración adicional de la tabla
        tableUsuarios.setShowGrid(false);
        tableUsuarios.setIntercellSpacing(new Dimension(0, 0));
        tableUsuarios.setRowHeight(30);
        tableUsuarios.setAutoCreateRowSorter(true);
    
        tableUsuarios.getTableHeader().setReorderingAllowed(false);

        ////////////////////////
        jPanelUsuarios.setBackground(new java.awt.Color(250, 250, 250));
        jPanelUsuarios.setOpaque(true);
      
        jScrollPane1.getViewport().setOpaque(true);
        jScrollPane1.getViewport().setBackground(new Color(250, 250, 250));
        initData();

        cargarRoles();
    }

    private void initData() {
        // 1. Configurar el modelo de tabla
        String[] columnNames = {"", "Nombres", "Apellidos", "DNI", "Teléfono", "Usuario", "Contraseña", "Rol", "Estado", "idUsuario"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Hacer todas las celdas no editables
            }

            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 0) {
                    return Icon.class; // Columna de icono
                }
                return Object.class;
            }
        };

        tableUsuarios.setModel(model);

        // 2. Configurar columnas
        TableColumn iconColumn = tableUsuarios.getColumnModel().getColumn(0);
        iconColumn.setPreferredWidth(70);
        iconColumn.setMaxWidth(70);
        iconColumn.setMinWidth(70);
        tableUsuarios.setRowHeight(70); // o más si deseas una imagen más grande


        // Ocultar columna de ID
        TableColumn idColumn = tableUsuarios.getColumnModel().getColumn(9);
        idColumn.setMinWidth(0);
        idColumn.setMaxWidth(0);
        idColumn.setPreferredWidth(0);

        tableUsuarios.getColumnModel().getColumn(7).setHeaderValue("Rol");
        tableUsuarios.getColumnModel().getColumn(7).setPreferredWidth(150);

        // 3. Configurar renderizador para la columna de icono
        tableUsuarios.setDefaultRenderer(Icon.class, new TableGradientCell() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                JLabel label = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                label.setIcon((Icon) value);
                label.setText("");
                label.setHorizontalAlignment(JLabel.CENTER);
                return label;
            }
        });

        tableUsuarios.setDefaultRenderer(Object.class, new TableGradientCell());

        tableUsuarios.setShowGrid(true);
        tableUsuarios.setGridColor(Color.BLACK);
        tableUsuarios.setIntercellSpacing(new Dimension(1, 1));
        // 3. Configuraciones de estilo (las que tenías originalmente)
        
        jScrollPane1.getVerticalScrollBar().putClientProperty(FlatClientProperties.STYLE, ""
                + "hoverTrackColor:null");

        jScrollPane1.setVerticalScrollBar(new ScrollBar());
        jScrollPane1.setHorizontalScrollBar(new ScrollBar());

        // 4. Cargar datos
        cargarUsuarios();
    }

    private void cargarUsuarios() {
        DefaultTableModel model = (DefaultTableModel) tableUsuarios.getModel();
        model.setRowCount(0); // Limpiar tabla
        LoginDAO userDao = new LoginDAO();
        RolDao rolDao = new RolDao(); // Agrega esto
        List<login> usuarios = userDao.listarUsuarios();

        for (login usuario : usuarios) {
            Icon icono;
            if (usuario.getFoto() != null && usuario.getFoto().length > 0) {
                icono = redondearImagen(usuario.getFoto(), 60);
            } else {
                try {
                    BufferedImage imagenDefault = ImageIO.read(getClass().getResource("/com/raven/icon/profile.jpg"));
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    ImageIO.write(imagenDefault, "jpg", baos);
                    icono = redondearImagen(baos.toByteArray(), 60);
                } catch (IOException e) {
                    System.out.println("Error al cargar imagen por defecto: " + e.toString());
                    icono = UIManager.getIcon("OptionPane.informationIcon");
                }
            }

            // Obtener el nombre del rol desde su ID
            String nombreRol = rolDao.obtenerNombreRolPorId(usuario.getIdRol());

            model.addRow(new Object[]{
                icono, // Foto
                usuario.getNombre(), // Nombres
                usuario.getApellido(), // Apellidos
                usuario.getDNI(), // DNI
                usuario.getCelular(), // Teléfono
                usuario.getUsuario(), // Usuario
                usuario.getPassword(), // Contraseña
                nombreRol, // Rol (Nombre)
                usuario.getEstado() == 1 ? "Activo" : "Inactivo", // Estado
                usuario.getId() // ID oculto
            });
        }
    }
    
    private void cargarRoles() {
        RolDao dao = new RolDao();
        List<rol> roles = dao.listarRoles();
        comboBox1.removeAllItems();
        for (rol r : roles) {
            comboBox1.addItem(r); // Agregamos objeto Rol, que mostrará solo el nombre
        }
            comboBox1.setSelectedIndex(-1); 

          }

    public static ImageIcon redondearImagen(byte[] bytes, int diameter) {
        try {
            BufferedImage original = ImageIO.read(new ByteArrayInputStream(bytes));
            BufferedImage scaled = new BufferedImage(diameter, diameter, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2 = scaled.createGraphics();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Recorte circular
            Ellipse2D circle = new Ellipse2D.Float(0, 0, diameter, diameter);
            g2.setClip(circle);

            // Escalado y dibujado
            g2.drawImage(original.getScaledInstance(diameter, diameter, Image.SCALE_SMOOTH), 0, 0, diameter, diameter, null);
            g2.dispose();

            return new ImageIcon(scaled);
        } catch (IOException e) {
            return null;
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelUsuarios = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        button1 = new com.raven.swing.Button();
        jLabel7 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jTextNombres = new javax.swing.JTextField();
        jTextApellidos = new javax.swing.JTextField();
        jTextDni = new javax.swing.JTextField();
        jTextTelefono = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jTextUsuario = new javax.swing.JTextField();
        jSeparator5 = new javax.swing.JSeparator();
        jTextContraseña = new javax.swing.JTextField();
        jSeparator6 = new javax.swing.JSeparator();
        comboBox1 = new com.raven.swing.ComboBox();
        jLabel8 = new javax.swing.JLabel();
        INICIARSESION = new javax.swing.JLabel();
        buttonGestionRol = new com.raven.swing.Button();
        button3 = new com.raven.swing.Button();
        buttonGuardarUsuario = new com.raven.swing.Button();
        button5 = new com.raven.swing.Button();
        jCheckBoxEstado = new com.raven.swing.JCheckBoxCustom();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableUsuarios = new javax.swing.JTable();

        setBackground(new java.awt.Color(250, 250, 250));

        jPanelUsuarios.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel6.setText("Contraseña:");
        jPanelUsuarios.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 130, -1, -1));

        jLabel2.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel2.setText("Apellidos:");
        jPanelUsuarios.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 130, -1, -1));

        button1.setText("Eliminar Usuario");
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });
        jPanelUsuarios.add(button1, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 480, 130, 40));

        jLabel7.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel7.setText("Rol: ");
        jPanelUsuarios.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 190, -1, -1));

        jLabel4.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel4.setText("Telefono:");
        jPanelUsuarios.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 230, -1, -1));

        jLabel3.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel3.setText("Dni:");
        jPanelUsuarios.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 180, -1, -1));

        jLabel5.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel5.setText("Usuario:");
        jPanelUsuarios.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 80, -1, -1));

        jTextNombres.setBorder(null);
        jTextNombres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextNombresActionPerformed(evt);
            }
        });
        jPanelUsuarios.add(jTextNombres, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 80, 310, -1));

        jTextApellidos.setBorder(null);
        jPanelUsuarios.add(jTextApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 130, 310, -1));

        jTextDni.setBorder(null);
        jPanelUsuarios.add(jTextDni, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 180, 310, -1));

        jTextTelefono.setBorder(null);
        jPanelUsuarios.add(jTextTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 230, 310, -1));

        jSeparator1.setForeground(new java.awt.Color(3, 155, 216));
        jPanelUsuarios.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 250, 310, 10));

        jSeparator2.setForeground(new java.awt.Color(3, 155, 216));
        jPanelUsuarios.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 100, 310, 10));

        jSeparator3.setForeground(new java.awt.Color(3, 155, 216));
        jPanelUsuarios.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, 310, 10));

        jSeparator4.setForeground(new java.awt.Color(3, 155, 216));
        jPanelUsuarios.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 200, 310, 10));

        jTextUsuario.setBorder(null);
        jTextUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextUsuarioActionPerformed(evt);
            }
        });
        jPanelUsuarios.add(jTextUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 80, 310, -1));

        jSeparator5.setForeground(new java.awt.Color(3, 155, 216));
        jPanelUsuarios.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 100, 310, 10));

        jTextContraseña.setBorder(null);
        jTextContraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextContraseñaActionPerformed(evt);
            }
        });
        jPanelUsuarios.add(jTextContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 130, 310, -1));

        jSeparator6.setForeground(new java.awt.Color(3, 155, 216));
        jPanelUsuarios.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 150, 310, 10));

        comboBox1.setLabelText("Seleccionar...");
        jPanelUsuarios.add(comboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 180, 310, 50));

        jLabel8.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel8.setText("Nombres:");
        jPanelUsuarios.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 80, -1, -1));

        INICIARSESION.setFont(new java.awt.Font("Roboto Black", 1, 18)); // NOI18N
        INICIARSESION.setForeground(new java.awt.Color(102, 102, 102));
        INICIARSESION.setText("Usuarios");
        jPanelUsuarios.add(INICIARSESION, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 20, -1, -1));

        buttonGestionRol.setText("Gestionar Roles");
        buttonGestionRol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonGestionRolActionPerformed(evt);
            }
        });
        jPanelUsuarios.add(buttonGestionRol, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 240, 310, 20));

        button3.setText("Añadir Rol");
        button3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button3ActionPerformed(evt);
            }
        });
        jPanelUsuarios.add(button3, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 240, 310, 20));

        buttonGuardarUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/GuardarTodo.png"))); // NOI18N
        buttonGuardarUsuario.setText("Guardar Usuario");
        buttonGuardarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonGuardarUsuarioActionPerformed(evt);
            }
        });
        jPanelUsuarios.add(buttonGuardarUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 350, 130, 40));

        button5.setText("Editar Usuario");
        button5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button5ActionPerformed(evt);
            }
        });
        jPanelUsuarios.add(button5, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 410, 130, 40));

        jCheckBoxEstado.setText("Estado");
        jPanelUsuarios.add(jCheckBoxEstado, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 280, 140, -1));

        tableUsuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tableUsuarios);

        jPanelUsuarios.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 340, 760, 210));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanelUsuarios, javax.swing.GroupLayout.DEFAULT_SIZE, 1106, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanelUsuarios, javax.swing.GroupLayout.DEFAULT_SIZE, 594, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jTextNombresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextNombresActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextNombresActionPerformed

    private void jTextUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextUsuarioActionPerformed

    private void jTextContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextContraseñaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextContraseñaActionPerformed

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_button1ActionPerformed

    private void buttonGestionRolActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonGestionRolActionPerformed


        JFrame frame = new JFrame("Gestión de Roles");
        frame.setUndecorated(true); // Quita barra de título y botones
        frame.setSize(650, 500);
        frame.setLocationRelativeTo(null); // Centrar la ventana

        // Agregar nuestro panel
        GestionarRoles panelRoles = new GestionarRoles();

        frame.add(panelRoles);

        // Mostrar la ventana
        frame.setVisible(true);

    }//GEN-LAST:event_buttonGestionRolActionPerformed

    private void button3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_button3ActionPerformed

    private void buttonGuardarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonGuardarUsuarioActionPerformed
        // Validaciones básicas
        if (jTextNombres.getText().trim().isEmpty()
                || jTextApellidos.getText().trim().isEmpty()
                || jTextDni.getText().trim().isEmpty()
                || jTextTelefono.getText().trim().isEmpty()
                || jTextUsuario.getText().trim().isEmpty()
                || jTextContraseña.getText().trim().isEmpty()
                || comboBox1.getSelectedIndex() == -1
                ||(!jCheckBoxEstado.isSelected() && !jCheckBoxEstado.isEnabled())) {

            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.");
            return;
        }

        // Crear objeto login (usuario)
        login usuario = new login();
        usuario.setNombre(jTextNombres.getText().trim());
        usuario.setApellido(jTextApellidos.getText().trim());
        usuario.setDNI(Integer.parseInt(jTextDni.getText().trim()));
        usuario.setCelular(Integer.parseInt(jTextTelefono.getText().trim()));
        usuario.setUsuario(jTextUsuario.getText().trim());
        usuario.setPassword(jTextContraseña.getText().trim());
        rol rolSeleccionado = (rol) comboBox1.getSelectedItem();
        usuario.setIdRol(rolSeleccionado.getIdRol()); // Suponiendo que hay un método getId()
        usuario.setEstado(jCheckBoxEstado.isSelected()?1:0); // Activo por defecto

        LoginDAO dao = new LoginDAO();

    if (idUsuarioEditando == null) {
        // Nuevo usuario
        if (dao.existeUsuario(usuario.getUsuario())) {
            JOptionPane.showMessageDialog(this, "El nombre de usuario ya existe.");
            return;
        }
        if (dao.registrarUsuario(usuario)) {
            JOptionPane.showMessageDialog(this, "Usuario registrado correctamente.");
        } else {
            JOptionPane.showMessageDialog(this, "Error al registrar usuario.");
        }
    } 
    // Refrescar tabla y limpiar campos
    cargarUsuarios();

    }//GEN-LAST:event_buttonGuardarUsuarioActionPerformed

    private void button5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_button5ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel INICIARSESION;
    private com.raven.swing.Button button1;
    private com.raven.swing.Button button3;
    private com.raven.swing.Button button5;
    private com.raven.swing.Button buttonGestionRol;
    private com.raven.swing.Button buttonGuardarUsuario;
    private com.raven.swing.ComboBox comboBox1;
    private com.raven.swing.JCheckBoxCustom jCheckBoxEstado;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanelUsuarios;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JTextField jTextApellidos;
    private javax.swing.JTextField jTextContraseña;
    private javax.swing.JTextField jTextDni;
    private javax.swing.JTextField jTextNombres;
    private javax.swing.JTextField jTextTelefono;
    private javax.swing.JTextField jTextUsuario;
    private javax.swing.JTable tableUsuarios;
    // End of variables declaration//GEN-END:variables
}
