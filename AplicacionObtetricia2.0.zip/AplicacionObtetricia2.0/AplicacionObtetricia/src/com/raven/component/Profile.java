package com.raven.component;

import Controlador.LoginDAO;
import Controlador.login;
import com.raven.main.Main.SistemaPerfil;
import java.awt.Dimension;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import javax.swing.ImageIcon;
import javax.swing.SwingUtilities;

public class Profile extends javax.swing.JPanel {

    public Profile() {
        initComponents();
        setOpaque(false);
        // Registrar este componente para recibir actualizaciones
        SistemaPerfil.addListener(bytes -> {
            SwingUtilities.invokeLater(() -> {
                actualizarFoto(bytes);
            });
        });
         cargarFotoUsuario(); // Nuevo método

    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(215, 140); // Ajusta la altura según necesites
    }

    public void actualizarFoto(byte[] imagenBytes) {
        try {
            ImageIcon icon = new ImageIcon(imagenBytes);
            pic.setIcon(icon);
            repaint(); // Forzar redibujado
        } catch (Exception e) {
            // Si hay error, cargar imagen por defecto
            pic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/profile.jpg")));
        }
    }

    // Alternativa para actualizar desde archivo
    public void actualizarFoto(File archivoImagen) {
        try {
            byte[] bytes = Files.readAllBytes(archivoImagen.toPath());
            actualizarFoto(bytes);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void cargarFotoUsuario() {
    login usuario = LoginDAO.obtenerUsuarioLogueado();
    if (usuario != null && usuario.getFoto() != null) {
        actualizarFoto(usuario.getFoto());
    } else {
        // Foto por defecto si no hay
        pic.setIcon(new ImageIcon(getClass().getResource("/com/raven/icon/profile.jpg")));
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pic = new com.raven.swing.ImageAvatar();

        pic.setForeground(new java.awt.Color(245, 245, 245));
        pic.setBorderSize(2);
        pic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/profile.jpg"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pic, javax.swing.GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(pic, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.raven.swing.ImageAvatar pic;
    // End of variables declaration//GEN-END:variables
}
