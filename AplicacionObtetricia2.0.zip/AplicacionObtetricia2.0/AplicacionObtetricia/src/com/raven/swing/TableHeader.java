package com.raven.swing;

import com.formdev.flatlaf.FlatClientProperties;
import java.awt.Color;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.border.EmptyBorder;

public class TableHeader extends JLabel {
    
    public TableHeader(String text) {
        super(text);
        setOpaque(true);
        setBackground(new Color(250, 250, 250)); // Fondo gris claro
        setFont(new java.awt.Font("sansserif", 1, 12)); // Negrita tamaño 12
        setForeground(new Color(102, 102, 102)); // Texto gris oscuro
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 2, 0, Color.BLACK), // Borde inferior negro de 2px
                new EmptyBorder(10, 5, 10, 5) // Espaciado interno
        ));
        setHorizontalAlignment(JLabel.CENTER); // Alineación centrada
        putClientProperty(FlatClientProperties.STYLE, ""
                + "border:0,0,1,0,$TableHeader.bottomSeparatorColor;"
                + "height:28");
        
        
    }
    
}
